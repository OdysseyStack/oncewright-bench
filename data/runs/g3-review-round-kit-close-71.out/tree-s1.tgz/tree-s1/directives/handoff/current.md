# Handoff: refunds-fixes committed. Next: push/PR on the user's word, then refunds Slice 3

**Read first:** `ledger-check-not-installed`: `npm run check` here runs only the tests, and the export import check is skipped.

**State:** on branch `refunds-fixes`, 1 commit ahead of `main` (`c8767e3`), clean apart from this file. Not pushed, no PR. Push or open a PR only if the user asks.
`c8767e3` dealt with `review/findings-refunds.md`:
- #1 accepted. Partial-refund tax is now `percentOf(items, taxRate)` on the summed amount (`src/refunds.js:26`). Test: "a partial refund's tax is charged on the lines' summed amount…" in `test/refunds.test.js`.
- #3 accepted. `linesFor` uses a `Set` (`src/refunds.js:7-11`).
- #2 rejected. It conflicts with refunds plan Slice 2 point 5 (the separate negative `Restocking fee` line).
31/31 tests pass.

**First:** ask whether to push `refunds-fixes` and open a PR against `main`.

**Later:**
1. Refunds Slice 3: partial refunds of discounted orders (`docs/plans/2026-09-30-refunds.md`, "Slice 3"). It changes `src/refunds.js` (the throw at line 23, the `items`/`fee`/`tax` lines 24-26, and the note rows) and `test/refunds.test.js` (the `/discount/` throw test). It uses `computeTotals(...).lines[].net`.
2. Slice 4 (round tax) stays frozen: leave `percentOf` in `src/money.js` alone until finance amends the September filing.

**Open flags:**
- CodeRabbit #2: should the refund note show `Items` after the fee and drop the `Restocking fee` row? That would mean changing plan Slice 2 point 5 first. The user hasn't decided.
