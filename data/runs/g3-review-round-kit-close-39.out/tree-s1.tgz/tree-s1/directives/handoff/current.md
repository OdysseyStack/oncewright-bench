# Handoff from 2026-11-19 (refunds CodeRabbit fixes)

**Read first:** `ledger-check-not-installed`: `npm run check` here runs only the tests, not the export import check.

**State:** branch `refunds-fixes`, one commit f41c427 over `main` (1e55dc6), clean tree, not pushed, no PR.
Push or open a PR only when the user asks.

What that commit did, from `review/findings-refunds.md`:
- Finding 1 (fixed): partial-refund tax is now `percentOf(items, config.taxRate)` on the summed lines
  (`src/refunds.js:27`), per refunds plan Slice 2 point 1; new test in `test/refunds.test.js:26-37`
  (fails on the old code).
- Finding 3 (fixed): `linesFor` uses a `Set` (`src/refunds.js:7-11`).
- Finding 2 (not done): CodeRabbit wanted `Items` after the fee and no `Restocking fee` row.
  The plan's Slice 2 points 3 and 5 say the opposite, so the note is unchanged.

**First:** ask the user whether to push `refunds-fixes` and open a PR. After a push to a PR branch,
dispatch `/odyssey:cr-triage` in the background, as the global CLAUDE.md says.

**Later:** Refunds Slice 3 (`docs/plans/2026-09-30-refunds.md`, "Slice 3": partial refunds of
discounted orders, using `computeTotals(...).lines[].net`). Slice 4 (round `percentOf`) waits on
Finance. Don't touch `percentOf` before then.

**Open flags:**
- Finding 2 (note layout) is turned down pending the user. If they want CodeRabbit's layout, change the
  plan's Slice 2 point 5 first, then `renderRefundNote` and the note tests.
