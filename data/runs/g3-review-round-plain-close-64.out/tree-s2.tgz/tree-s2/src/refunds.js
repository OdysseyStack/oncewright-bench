// Refunds: a whole order (the refund plan's Slice 1), or some of its lines (Slice 2), with or
// without a discount code (Slice 3).
import { config } from "./config.js";
import { formatMoney, percentOf, sumCents } from "./money.js";
import { computeTotals } from "./totals.js";

// The order's lines a refund covers: those whose SKUs are listed, or all of them.
const linesFor = (order, skus) => {
  if (skus === undefined) return order.items;
  const wanted = new Set(skus);
  return order.items.filter((item) => wanted.has(item.sku));
};

// The refunded lines, each with what it pays back: its net, the line's amount less its share of
// any discount, from computeTotals.
const refundedLines = (order, options, t) => {
  const net = new Map(order.items.map((item, i) => [item, t.lines[i].net]));
  return linesFor(order, options.skus).map((item) => ({ item, net: net.get(item) }));
};

// What a refund pays back, in cents: { items, fee, shipping, tax, total }. options: the options the
// order was priced with (pickup, code), plus skus, the lines to refund (all of them when absent),
// and opened, the refunded lines that keep a restocking fee.
export function refundFor(order, options = {}) {
  const t = computeTotals(order, options);
  const { skus, opened = [] } = options;
  const unknown = [...(skus ?? []), ...opened].find((sku) => !order.items.some((item) => item.sku === sku));
  if (unknown !== undefined) throw new Error(`SKU not on the order: ${unknown}`);
  const lines = refundedLines(order, options, t);
  const whole = lines.length === order.items.length;
  // The nets add up to the order's subtotal less its discount, so a whole refund pays back what it charged.
  const items = sumCents(lines.map((line) => line.net));
  const fee = sumCents(lines.filter((line) => opened.includes(line.item.sku)).map((line) => percentOf(line.net, config.restockingFee)));
  // The tax on the summed amount, as computeTotals charges it, not the sum of each line's tax.
  const tax = whole ? t.tax : percentOf(items, config.taxRate);
  const shipping = whole ? t.shipping : 0;
  return { items, fee, shipping, tax, total: items - fee + shipping + tax };
}

// The note the customer gets with a refund: the refunded lines at their net prices, as the receipt
// shows them, then the totals.
export function renderRefundNote(order, options = {}) {
  const r = refundFor(order, options);
  const rows = [
    ...refundedLines(order, options, computeTotals(order, options)).map(({ item, net }) => [`${item.qty} x ${item.name}`, net]),
    null,
    ...(r.fee ? [["Restocking fee", -r.fee]] : []),
    ["Items", r.items],
    ["Shipping", r.shipping],
    ["Tax", r.tax],
    ["Refund", r.total],
  ].map((row) => row && [row[0], formatMoney(row[1])]);
  const width = Math.max(...rows.filter(Boolean).map(([label, amount]) => label.length + amount.length)) + 2;
  return [
    `Refund for order ${order.id ?? "(no id)"}`,
    "",
    ...rows.map((row) => (row ? row[0] + row[1].padStart(width - row[0].length) : "")),
  ].join("\n");
}
