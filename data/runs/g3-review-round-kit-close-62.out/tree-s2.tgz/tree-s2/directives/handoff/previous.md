**Read first:** `ledger-check-not-installed`: `npm run check` here runs only the tests; the export import check is skipped.

**State:** branch `refunds-fixes`, one commit `c370bc9` on top of `main` ("Refunds: tax a partial refund on the lines' summed amount"). It's not pushed and has no PR. The tree is clean apart from this file. CodeRabbit's three findings in `review/findings-refunds.md` are handled: two fixed (partial-refund tax on the summed amount; a `Set` in `linesFor`), one rejected (folding the restocking fee into the note's `Items` line). The commit message records why. The refunds plan's Slice 2 stays marked done. Git rule: push, PR or merge only when the user asks.

**First:** ask the user whether to push `refunds-fixes` and open a PR, and whether they accept the rejection of finding 2. The rejection rests on `docs/plans/2026-09-30-refunds.md` Slice 2 point 5 (a separate negative `Restocking fee` line) and Slice 3 point 2 (`Items` is the sum of the refunded lines). If they want the fee folded in, that changes the plan as well as `src/refunds.js` `renderRefundNote` (about lines 33-50) and the note test in `test/refunds.test.js`.

**Later:**
1. Refunds Slice 3, partial refunds of discounted orders (`docs/plans/2026-09-30-refunds.md`, "Slice 3"). Files: `src/refunds.js` `refundFor` (about lines 16-30: drop the discount throw and use `computeTotals(...).lines[].net` for items, fee and tax), `renderRefundNote` (net prices), `bin/refund-order.js`, the README's "not supported yet" note, and `test/refunds.test.js`. Start with `/odyssey:prove-it` (test first).
2. Slice 4 (rounding in `percentOf`) waits on Finance's filing amendment. Until then, leave `percentOf` in `src/money.js` and every amount it gives as they are.

**Open flags:**
- The user hasn't ruled on rejecting CodeRabbit finding 2 (the restocking-fee note layout).
- The export import check has never run on this machine (`ledger-check` missing).
