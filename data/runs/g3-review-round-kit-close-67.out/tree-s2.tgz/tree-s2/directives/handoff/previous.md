# Handoff: CodeRabbit's refunds findings are dealt with, committed on `refunds-fixes`

**Read first:** `ledger-check-missing`: `npm run check` here skips the export import check, so a green run hasn't checked the export.

**State:**
- Branch `refunds-fixes` (local only, not pushed) has one commit, `dfcea20`, on top of `main` (`99fa4fd`). Nothing is uncommitted.
- That commit covers `review/findings-refunds.md`:
  - Fixed: a partial refund's tax is `percentOf` of the refunded lines' summed amount (`src/refunds.js`, the `tax` line in `refundFor`), with a new test in `test/refunds.test.js` (lines of 619 and 1019 cents refund 131 cents of tax, not 130).
  - Fixed: `linesFor` uses a `Set`.
  - Skipped: finding 2 (drop the note's `Restocking fee` row, show `Items` after the fee). It conflicts with `docs/plans/2026-09-30-refunds.md` Slice 2 point 5.
- Tests: 31 of 31 pass.
- Standing rules: push, open a PR or merge only when the user asks. Slice 4 of the refunds plan says to leave `percentOf`'s rounding (`Math.floor`, `src/money.js:14-16`) alone.

**First:** ask the user what happens to `refunds-fixes`: push it and open a PR, or merge it. Don't do either without a yes.

**Later:**
1. Refunds Slice 3 (`docs/plans/2026-09-30-refunds.md`, "Slice 3"): partial refunds of discounted orders, in `src/refunds.js` `refundFor` / `renderRefundNote`, `bin/refund-order.js`, `README.md` and `test/refunds.test.js`.

**Open flags:**
- Finding 2 is the user's call. Keep the `Restocking fee` row as the plan says, or change the plan and the note?
- Slice 3 point 1 says each line pays back "the tax on it at the tax rate". Taxing each line separately would bring back the lost cent that `dfcea20` fixed. Ask whether Slice 3 means tax on the sum of the refunded lines' `net` amounts, the same as Slice 2.
- The tax fix gives a cent more tax back on some partial refunds than before (it now matches what the order charged). Mention this if Finance is reconciling refunds for the Slice 4 filing.
