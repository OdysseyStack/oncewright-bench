import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { refundFor, renderRefundNote } from "../src/refunds.js";

const at = (p) => fileURLToPath(new URL(p, import.meta.url));
const order = {
  id: "A-1040",
  items: [
    { sku: "BEANS-1KG", name: "House beans 1kg", unitPrice: 2400, qty: 1 },
    { sku: "FILTER-100", name: "Paper filters x100", unitPrice: 650, qty: 2 },
  ],
};

test("a refund pays back the whole order", () => {
  assert.deepEqual(refundFor(order), { items: 3700, fee: 0, shipping: 599, tax: 296, total: 4595 });
  assert.deepEqual(refundFor(order, { code: "SAVE10" }), { items: 3330, fee: 0, shipping: 599, tax: 266, total: 4195 });
});

test("a refund of some lines pays back their amount and its tax, and no shipping", () => {
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"] }), { items: 1300, fee: 0, shipping: 0, tax: 104, total: 1404 });
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100", "BEANS-1KG"] }), refundFor(order));
});

test("a partial refund's tax is taken on the lines' summed amount, as the order charged it", () => {
  // Per line, 8% of $6.19 and of $10.19 is 49 + 81 = 130 cents; on their sum, $16.38, it is 131.
  const three = {
    items: [
      { sku: "A", name: "A", unitPrice: 619, qty: 1 },
      { sku: "B", name: "B", unitPrice: 1019, qty: 1 },
      { sku: "C", name: "C", unitPrice: 500, qty: 1 },
    ],
  };
  assert.deepEqual(refundFor(three, { skus: ["A", "B"] }), { items: 1638, fee: 0, shipping: 0, tax: 131, total: 1769 });
});

test("an opened line keeps a 15% restocking fee", () => {
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"] }), { items: 2400, fee: 360, shipping: 0, tax: 192, total: 2232 });
});

test("a SKU not on the order is an error", () => {
  assert.throws(() => refundFor(order, { skus: ["TEA-50"] }), /TEA-50/);
  assert.throws(() => refundFor(order, { skus: ["BEANS-1KG"], opened: ["TEA-50"] }), /TEA-50/);
});

test("a partial refund of a discounted order pays back each line's net and the tax on it", () => {
  // SAVE10 takes 370 cents off $37.00: 240 from the beans' $24.00, 130 from the filters' $13.00.
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"], code: "SAVE10" }), { items: 1170, fee: 0, shipping: 0, tax: 93, total: 1263 });
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], code: "save10" }), { items: 2160, fee: 0, shipping: 0, tax: 172, total: 2332 });
});

test("a partial refund of a discounted order is taxed on the lines' summed nets", () => {
  // TAKE5's 500 cents split 145/238/117, so the nets are 474, 781 and 383. 8% of 474 + 781 = 1255 is
  // 100 cents; per line it would be 37 + 62 = 99.
  const three = {
    items: [
      { sku: "A", name: "A", unitPrice: 619, qty: 1 },
      { sku: "B", name: "B", unitPrice: 1019, qty: 1 },
      { sku: "C", name: "C", unitPrice: 500, qty: 1 },
    ],
  };
  assert.deepEqual(refundFor(three, { skus: ["A", "B"], code: "TAKE5" }), { items: 1255, fee: 0, shipping: 0, tax: 100, total: 1355 });
});

test("an opened line of a discounted order keeps 15% of its net", () => {
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"], code: "SAVE10" }), { items: 2160, fee: 324, shipping: 0, tax: 172, total: 2008 });
  assert.deepEqual(refundFor(order, { opened: ["BEANS-1KG"], code: "SAVE10" }), { items: 3330, fee: 324, shipping: 599, tax: 266, total: 3871 });
});

test("a whole refund of a discounted order, line by line, gives the same amounts as Slice 1", () => {
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG", "FILTER-100"], code: "SAVE10" }), refundFor(order, { code: "SAVE10" }));
  assert.deepEqual(refundFor(order, { code: "TAKE5", pickup: true }), { items: 3200, fee: 0, shipping: 0, tax: 256, total: 3456 });
});

test("the refund note shows each part", () => {
  assert.equal(
    renderRefundNote(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"] }),
    "Refund for order A-1040\n\n1 x House beans 1kg  $24.00\n\nRestocking fee       -$3.60\nItems                $24.00\nShipping              $0.00\nTax                   $1.92\nRefund               $22.32",
  );
});

test("the refund note of a discounted order prints each line at its net price", () => {
  assert.equal(
    renderRefundNote(order, { skus: ["FILTER-100"], code: "SAVE10" }),
    "Refund for order A-1040\n\n2 x Paper filters x100  $11.70\n\nItems                   $11.70\nShipping                 $0.00\nTax                      $0.93\nRefund                  $12.63",
  );
  // The lines it prints add up to Items, as the bookkeeper's import checks.
  const note = renderRefundNote(order, { code: "TAKE5" });
  assert.match(note, /^1 x House beans 1kg +\$20\.76$/m);
  assert.match(note, /^2 x Paper filters x100 +\$11\.24$/m);
  assert.match(note, /^Items +\$32\.00$/m);
});

test("refund-order prints the note, or --json the amounts", () => {
  const cli = (...args) => spawnSync(process.execPath, [at("../bin/refund-order.js"), ...args], { encoding: "utf8" });
  assert.match(cli(at("../examples/order.json")).stdout, /^Refund +\$45\.95$/m);
  assert.deepEqual(JSON.parse(cli(at("../examples/order.json"), "--json").stdout), { items: 3700, fee: 0, shipping: 599, tax: 296, total: 4595 });
  assert.match(cli(at("../examples/order.json"), "--sku", "BEANS-1KG", "--opened", "BEANS-1KG").stdout, /^Restocking fee +-\$3\.60$/m);
  const discounted = cli(at("../examples/order.json"), "--code", "SAVE10", "--sku", "FILTER-100", "--json");
  assert.equal(discounted.status, 0);
  assert.deepEqual(JSON.parse(discounted.stdout), { items: 1170, fee: 0, shipping: 0, tax: 93, total: 1263 });
  assert.match(cli(at("../examples/order.json"), "--code", "SAVE10", "--sku", "FILTER-100").stdout, /^2 x Paper filters x100 +\$11\.70$/m);
  const unknown = cli(at("../examples/order.json"), "--sku", "TEA-50");
  assert.equal(unknown.status, 1);
  assert.match(unknown.stderr, /TEA-50/);
  assert.equal(cli().status, 1);
});
