import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { refundFor, renderRefundNote } from "../src/refunds.js";

const at = (p) => fileURLToPath(new URL(p, import.meta.url));
const order = {
  id: "A-1040",
  items: [
    { sku: "BEANS-1KG", name: "House beans 1kg", unitPrice: 2400, qty: 1 },
    { sku: "FILTER-100", name: "Paper filters x100", unitPrice: 650, qty: 2 },
  ],
};

test("a refund pays back the whole order", () => {
  assert.deepEqual(refundFor(order), { items: 3700, fee: 0, shipping: 599, tax: 296, total: 4595 });
  assert.deepEqual(refundFor(order, { code: "SAVE10" }), { items: 3330, fee: 0, shipping: 599, tax: 266, total: 4195 });
});

test("a refund of some lines pays back their amount and its tax, and no shipping", () => {
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"] }), { items: 1300, fee: 0, shipping: 0, tax: 104, total: 1404 });
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100", "BEANS-1KG"] }), refundFor(order));
});

test("the tax on some lines is taken on their summed amount, as the order charged it", () => {
  const big = {
    id: "A-1050",
    items: [
      { sku: "DRIP-619", name: "Drip cones", unitPrice: 619, qty: 1 },
      { sku: "KETTLE-1019", name: "Kettle descaler", unitPrice: 1019, qty: 1 },
      { sku: "BEANS-1KG", name: "House beans 1kg", unitPrice: 2400, qty: 1 },
    ],
  };
  // Per line: 49 + 81 = 130 cents; on the sum, 1638 cents: 131 cents.
  assert.deepEqual(refundFor(big, { skus: ["DRIP-619", "KETTLE-1019"] }), { items: 1638, fee: 0, shipping: 0, tax: 131, total: 1769 });
});

test("an opened line keeps a 15% restocking fee", () => {
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"] }), { items: 2400, fee: 360, shipping: 0, tax: 192, total: 2232 });
});

test("a SKU not on the order is an error", () => {
  assert.throws(() => refundFor(order, { skus: ["TEA-50"] }), /TEA-50/);
});

// The discount shares on `order`: SAVE10 takes 240 and 130 off the lines (nets 2160 and 1170);
// TAKE5 takes 324 and 176 (nets 2076 and 1124).
test("a refund of some lines of a discounted order pays back their net and the tax on it", () => {
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"], code: "SAVE10" }), { items: 1170, fee: 0, shipping: 0, tax: 93, total: 1263 });
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"], code: "TAKE5" }), { items: 1124, fee: 0, shipping: 0, tax: 89, total: 1213 });
});

test("an opened line of a discounted order keeps 15% of its net", () => {
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"], code: "SAVE10" }), { items: 2160, fee: 324, shipping: 0, tax: 172, total: 2008 });
});

test("refunding every line of a discounted order pays back the whole order", () => {
  for (const code of ["SAVE10", "TAKE5"]) {
    assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG", "FILTER-100"], code }), refundFor(order, { code }));
  }
  assert.deepEqual(refundFor(order, { code: "TAKE5" }), { items: 3200, fee: 0, shipping: 599, tax: 256, total: 4055 });
});

test("the refund note of a discounted order prints each line at its net, adding up to Items", () => {
  const big = {
    id: "A-1050",
    items: [
      { sku: "DRIP-619", name: "Drip cones", unitPrice: 619, qty: 1 },
      { sku: "KETTLE-1019", name: "Kettle descaler", unitPrice: 1019, qty: 1 },
      { sku: "BEANS-1KG", name: "House beans 1kg", unitPrice: 2400, qty: 1 },
    ],
  };
  // TAKE5 on 4038 cents: shares 77, 126 and 297, so nets 542, 893 and 2103; 542 + 893 = 1435.
  assert.equal(
    renderRefundNote(big, { skus: ["DRIP-619", "KETTLE-1019"], code: "TAKE5" }),
    [
      "Refund for order A-1050",
      "",
      "1 x Drip cones       $5.42",
      "1 x Kettle descaler  $8.93",
      "",
      "Items               $14.35",
      "Shipping             $0.00",
      "Tax                  $1.14",
      "Refund              $15.49",
    ].join("\n"),
  );
});

test("the refund note shows each part", () => {
  assert.equal(
    renderRefundNote(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"] }),
    "Refund for order A-1040\n\n1 x House beans 1kg  $24.00\n\nRestocking fee       -$3.60\nItems                $24.00\nShipping              $0.00\nTax                   $1.92\nRefund               $22.32",
  );
});

test("refund-order prints the note, or --json the amounts", () => {
  const cli = (...args) => spawnSync(process.execPath, [at("../bin/refund-order.js"), ...args], { encoding: "utf8" });
  assert.match(cli(at("../examples/order.json")).stdout, /^Refund +\$45\.95$/m);
  assert.deepEqual(JSON.parse(cli(at("../examples/order.json"), "--json").stdout), { items: 3700, fee: 0, shipping: 599, tax: 296, total: 4595 });
  assert.match(cli(at("../examples/order.json"), "--sku", "BEANS-1KG", "--opened", "BEANS-1KG").stdout, /^Restocking fee +-\$3\.60$/m);
  assert.deepEqual(JSON.parse(cli(at("../examples/order.json"), "--code", "SAVE10", "--sku", "FILTER-100", "--json").stdout), { items: 1170, fee: 0, shipping: 0, tax: 93, total: 1263 });
  assert.match(cli(at("../examples/order.json"), "--code", "SAVE10", "--sku", "FILTER-100").stdout, /^2 x Paper filters x100 +\$11\.70$/m);
  const unknown = cli(at("../examples/order.json"), "--sku", "TEA-50");
  assert.equal(unknown.status, 1);
  assert.match(unknown.stderr, /TEA-50/);
  assert.equal(cli().status, 1);
});
