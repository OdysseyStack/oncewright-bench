// Refunds: a whole order (the refund plan's Slice 1), or some of its lines (Slices 2 and 3).
import { config } from "./config.js";
import { formatMoney, percentOf, sumCents } from "./money.js";
import { computeTotals } from "./totals.js";

// The lines a refund covers, each { item, net }: net is the line's amount less its share of any
// discount, from computeTotals' lines. Those whose SKUs are listed, or all of them.
const linesFor = (order, t, skus) => {
  const lines = order.items.map((item, i) => ({ item, net: t.lines[i].net }));
  if (skus === undefined) return lines;
  const wanted = new Set(skus);
  return lines.filter(({ item }) => wanted.has(item.sku));
};

// What a refund pays back, in cents: { items, fee, shipping, tax, total }. options: the options the
// order was priced with (pickup, code), plus skus, the lines to refund (all of them when absent),
// and opened, the refunded lines that keep a restocking fee.
export function refundFor(order, options = {}) {
  const t = computeTotals(order, options);
  const { skus, opened = [] } = options;
  const unknown = [...(skus ?? []), ...opened].find((sku) => !order.items.some((item) => item.sku === sku));
  if (unknown !== undefined) throw new Error(`SKU not on the order: ${unknown}`);
  const lines = linesFor(order, t, skus);
  const whole = lines.length === order.items.length;
  const fee = sumCents(lines.filter(({ item }) => opened.includes(item.sku)).map(({ net }) => percentOf(net, config.restockingFee)));
  const items = whole ? t.subtotal - t.discount : sumCents(lines.map(({ net }) => net));
  // Tax on the lines' summed nets, as computeTotals charges it, not summed per line.
  const tax = whole ? t.tax : percentOf(items, config.taxRate);
  const shipping = whole ? t.shipping : 0;
  return { items, fee, shipping, tax, total: items - fee + shipping + tax };
}

// The note the customer gets with a refund: the refunded lines at their net price, as the receipt
// prints them, then the totals.
export function renderRefundNote(order, options = {}) {
  const r = refundFor(order, options);
  const t = computeTotals(order, options);
  const rows = [
    ...linesFor(order, t, options.skus).map(({ item, net }) => [`${item.qty} x ${item.name}`, net]),
    null,
    ...(r.fee ? [["Restocking fee", -r.fee]] : []),
    ["Items", r.items],
    ["Shipping", r.shipping],
    ["Tax", r.tax],
    ["Refund", r.total],
  ].map((row) => row && [row[0], formatMoney(row[1])]);
  const width = Math.max(...rows.filter(Boolean).map(([label, amount]) => label.length + amount.length)) + 2;
  return [
    `Refund for order ${order.id ?? "(no id)"}`,
    "",
    ...rows.map((row) => (row ? row[0] + row[1].padStart(width - row[0].length) : "")),
  ].join("\n");
}
