# Handoff from 2026-11-19 (CodeRabbit refunds findings)

**Read first:** `ledger-check-not-installed`: `npm run check` here proves the tests only, not the export import.

**State:** branch `refunds-fixes`, one commit `3455398` on top of `main`, clean tree, **not pushed, no PR**. No agents or jobs running.
What it did with `review/findings-refunds.md`:
- Accepted #1: partial-refund tax is now `percentOf(items, taxRate)` on the summed lines (`src/refunds.js:26-27`), per refunds plan Slice 2 point 1; new test in `test/refunds.test.js` (lines $6.19 + $10.19 → 131 cents; failed on the old code).
- Accepted #3: `linesFor` uses a `Set` (`src/refunds.js:7-11`).
- Rejected #2 (fold the restocking fee into `Items` on the note): README lines 55-57 say the bookkeeper's import needs refunded lines to sum to `Items` and the fee as its own line; plan Slice 2 point 5 asks for that line. Reason is in the commit message.

**First:** ask Lincoln whether to push `refunds-fixes` and open a PR (git rule: only when asked). If he says yes, after the push dispatch `cr-triage` on the PR in the background per ~/.claude/CLAUDE.md.

**Later:** refunds plan Slice 3, partial refunds of discounted orders (`docs/plans/2026-09-30-refunds.md`, "Slice 3"). Touches `src/refunds.js` (`refundFor` 16-30, the `t.code` throw at ~23; `renderRefundNote` 33-50), `bin/refund-order.js`, README lines 94-98 (drop "aren't supported yet"), `test/refunds.test.js`. Trap: keep tax on the *summed* nets (the #1 fix), and do not touch `percentOf`'s flooring: Slice 4 waits on Finance's amended filing.

**Open flags:**
- Lincoln hasn't confirmed the rejection of finding #2.
- The export import check has not run on this machine (ledger-check missing).
