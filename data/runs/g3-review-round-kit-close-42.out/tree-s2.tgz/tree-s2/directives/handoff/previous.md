# Handoff: refunds fixes committed on `refunds-fixes`, not pushed

**Read first:** `ledger-check-not-installed` (a green `npm run check` here covers the tests only).

**State:** branch `refunds-fixes`, one commit `9fe9c3c` ("Refund the tax on some lines as the
order charged it") on top of `main`; working tree clean. Not pushed, no PR. Push or open a PR only
when the user asks.

What it did with `review/findings-refunds.md`:
- Accepted: partial-refund tax is now `percentOf(items, config.taxRate)` on the summed amount
  (`src/refunds.js:26-27`), per refunds plan Slice 2 point 1; test in `test/refunds.test.js:26-37`.
- Accepted nit: `linesFor` uses a `Set` (`src/refunds.js:7-11`).
- Rejected: folding the restocking fee into `Items` on the note. It breaks Slice 2 point 5 and the
  bookkeeper import rule in `README.md:55-57` (lines add up to `Items`; fee on its own line).

**First:** ask the user whether to push `refunds-fixes` and open a PR. After a push to a PR branch,
dispatch `/odyssey:cr-triage` in the background per the global CLAUDE.md.

**Later:** refunds Slice 3, partial refunds of discounted orders
(`docs/plans/2026-09-30-refunds.md:37-51`; changes `src/refunds.js:21-28`, its tests, and
`README.md:94-98` to drop the "not supported yet" note). Trap: point 1's "the tax on it at the tax
rate" can be read as per-line tax, which would bring back the cent-low bug just fixed. Charge the tax
on the summed nets, as `computeTotals` does. Do not touch `percentOf`'s flooring (Slice 4, held for
Finance).

**Open flags:**
- The user hasn't confirmed rejecting CodeRabbit's finding 2 (the restocking fee on the note).
- `ledger-check` isn't installed, so the export import check has never run in this checkout.
