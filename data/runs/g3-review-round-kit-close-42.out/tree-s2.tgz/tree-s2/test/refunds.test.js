import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { refundFor, renderRefundNote } from "../src/refunds.js";

const at = (p) => fileURLToPath(new URL(p, import.meta.url));
const order = {
  id: "A-1040",
  items: [
    { sku: "BEANS-1KG", name: "House beans 1kg", unitPrice: 2400, qty: 1 },
    { sku: "FILTER-100", name: "Paper filters x100", unitPrice: 650, qty: 2 },
  ],
};

test("a refund pays back the whole order", () => {
  assert.deepEqual(refundFor(order), { items: 3700, fee: 0, shipping: 599, tax: 296, total: 4595 });
  assert.deepEqual(refundFor(order, { code: "SAVE10" }), { items: 3330, fee: 0, shipping: 599, tax: 266, total: 4195 });
});

test("a refund of some lines pays back their amount and its tax, and no shipping", () => {
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"] }), { items: 1300, fee: 0, shipping: 0, tax: 104, total: 1404 });
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100", "BEANS-1KG"] }), refundFor(order));
});

test("the tax on some lines is charged on their summed amount, not line by line", () => {
  const odd = {
    id: "A-1041",
    items: [
      { sku: "DRIP-1", name: "Drip bags x6", unitPrice: 619, qty: 1 },
      { sku: "DRIP-2", name: "Drip bags x10", unitPrice: 1019, qty: 1 },
      { sku: "BEANS-1KG", name: "House beans 1kg", unitPrice: 2400, qty: 1 },
    ],
  };
  // Per line: 49 + 81 = 130. On the sum, 1638 cents at 8%: 131, what the order charged for them.
  assert.deepEqual(refundFor(odd, { skus: ["DRIP-1", "DRIP-2"] }), { items: 1638, fee: 0, shipping: 0, tax: 131, total: 1769 });
});

test("an opened line keeps a 15% restocking fee", () => {
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"] }), { items: 2400, fee: 360, shipping: 0, tax: 192, total: 2232 });
});

test("a SKU not on the order is an error", () => {
  assert.throws(() => refundFor(order, { skus: ["TEA-50"] }), /TEA-50/);
  assert.throws(() => refundFor(order, { skus: ["BEANS-1KG"], opened: ["TEA-50"], code: "SAVE10" }), /TEA-50/);
});

// SAVE10 takes 370 off this order: 240 of it from the beans (2400 -> 2160), 130 from the filters (1300 -> 1170).
test("a refund of some lines of a discounted order pays back their nets and the tax on them", () => {
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], code: "SAVE10" }), { items: 2160, fee: 0, shipping: 0, tax: 172, total: 2332 });
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"], code: "SAVE10" }), { items: 1170, fee: 0, shipping: 0, tax: 93, total: 1263 });
});

test("an opened line of a discounted order keeps 15% of its net", () => {
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"], code: "SAVE10" }), { items: 2160, fee: 324, shipping: 0, tax: 172, total: 2008 });
});

test("refunding every line of a discounted order gives the whole refund", () => {
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG", "FILTER-100"], code: "SAVE10" }), refundFor(order, { code: "SAVE10" }));
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG", "FILTER-100"], code: "SAVE10" }), { items: 3330, fee: 0, shipping: 599, tax: 266, total: 4195 });
});

test("the tax on some lines of a discounted order is charged on their summed nets, not line by line", () => {
  const odd = {
    id: "A-1042",
    items: [
      { sku: "DRIP-1", name: "Drip bags x6", unitPrice: 606, qty: 1 },
      { sku: "DRIP-2", name: "Drip bags x10", unitPrice: 1019, qty: 1 },
      { sku: "BEANS-1KG", name: "House beans 1kg", unitPrice: 2400, qty: 1 },
    ],
  };
  // Nets 546 and 917. Per line: 43 + 73 = 116. On the sum, 1463 cents at 8%: 117.
  assert.deepEqual(refundFor(odd, { skus: ["DRIP-1", "DRIP-2"], code: "SAVE10" }), { items: 1463, fee: 0, shipping: 0, tax: 117, total: 1580 });
});

test("the refund note shows each part", () => {
  assert.equal(
    renderRefundNote(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"] }),
    "Refund for order A-1040\n\n1 x House beans 1kg  $24.00\n\nRestocking fee       -$3.60\nItems                $24.00\nShipping              $0.00\nTax                   $1.92\nRefund               $22.32",
  );
});

test("the refund note of a discounted order prints each line at its net, and Items is their sum", () => {
  assert.equal(
    renderRefundNote(order, { skus: ["FILTER-100"], code: "SAVE10" }),
    "Refund for order A-1040\n\n2 x Paper filters x100  $11.70\n\nItems                   $11.70\nShipping                 $0.00\nTax                      $0.93\nRefund                  $12.63",
  );
  assert.match(renderRefundNote(order, { code: "SAVE10" }), /^1 x House beans 1kg +\$21\.60\n2 x Paper filters x100 +\$11\.70\n\nItems +\$33\.30$/m);
});

test("refund-order prints the note, or --json the amounts", () => {
  const cli = (...args) => spawnSync(process.execPath, [at("../bin/refund-order.js"), ...args], { encoding: "utf8" });
  assert.match(cli(at("../examples/order.json")).stdout, /^Refund +\$45\.95$/m);
  assert.deepEqual(JSON.parse(cli(at("../examples/order.json"), "--json").stdout), { items: 3700, fee: 0, shipping: 599, tax: 296, total: 4595 });
  assert.match(cli(at("../examples/order.json"), "--sku", "BEANS-1KG", "--opened", "BEANS-1KG").stdout, /^Restocking fee +-\$3\.60$/m);
  assert.deepEqual(JSON.parse(cli(at("../examples/order.json"), "--json", "--code", "SAVE10", "--sku", "BEANS-1KG").stdout), { items: 2160, fee: 0, shipping: 0, tax: 172, total: 2332 });
  assert.match(cli(at("../examples/order.json"), "--code", "SAVE10", "--sku", "FILTER-100").stdout, /^2 x Paper filters x100 +\$11\.70$/m);
  const unknown = cli(at("../examples/order.json"), "--sku", "TEA-50");
  assert.equal(unknown.status, 1);
  assert.match(unknown.stderr, /TEA-50/);
  assert.equal(cli().status, 1);
});
