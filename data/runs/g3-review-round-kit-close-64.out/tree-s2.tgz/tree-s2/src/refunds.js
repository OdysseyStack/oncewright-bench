// Refunds: a whole order (the refund plan's Slice 1), some of its lines (Slice 2), with or without a
// discount code (Slice 3).
import { config } from "./config.js";
import { formatMoney, percentOf, sumCents } from "./money.js";
import { computeTotals } from "./totals.js";

// The order's lines a refund covers, those whose SKUs are listed or all of them, each with its net:
// its amount less its share of the order's discount, from computeTotals(order, options).lines.
const linesFor = (order, totals, skus) => {
  const wanted = skus === undefined ? null : new Set(skus);
  return order.items
    .map((item, i) => ({ ...item, net: totals.lines[i].net }))
    .filter((item) => wanted === null || wanted.has(item.sku));
};

// What a refund pays back, in cents: { items, fee, shipping, tax, total }. options: the options the
// order was priced with (pickup, code), plus skus, the lines to refund (all of them when absent),
// and opened, the refunded lines that keep a restocking fee. Each line pays back its net.
export function refundFor(order, options = {}) {
  const t = computeTotals(order, options);
  const { skus, opened = [] } = options;
  const unknown = [...(skus ?? []), ...opened].find((sku) => !order.items.some((item) => item.sku === sku));
  if (unknown !== undefined) throw new Error(`SKU not on the order: ${unknown}`);
  const lines = linesFor(order, t, skus);
  const whole = lines.length === order.items.length;
  const openedSkus = new Set(opened);
  const fee = sumCents(lines.filter((item) => openedSkus.has(item.sku)).map((item) => percentOf(item.net, config.restockingFee)));
  const items = whole ? t.subtotal - t.discount : sumCents(lines.map((item) => item.net));
  const tax = whole ? t.tax : percentOf(items, config.taxRate);
  const shipping = whole ? t.shipping : 0;
  return { items, fee, shipping, tax, total: items - fee + shipping + tax };
}

// The note the customer gets with a refund: the refunded lines at their net prices, then the totals.
export function renderRefundNote(order, options = {}) {
  const r = refundFor(order, options);
  const rows = [
    ...linesFor(order, computeTotals(order, options), options.skus).map((item) => [`${item.qty} x ${item.name}`, item.net]),
    null,
    ...(r.fee ? [["Restocking fee", -r.fee]] : []),
    ["Items", r.items],
    ["Shipping", r.shipping],
    ["Tax", r.tax],
    ["Refund", r.total],
  ].map((row) => row && [row[0], formatMoney(row[1])]);
  const width = Math.max(...rows.filter(Boolean).map(([label, amount]) => label.length + amount.length)) + 2;
  return [
    `Refund for order ${order.id ?? "(no id)"}`,
    "",
    ...rows.map((row) => (row ? row[0] + row[1].padStart(width - row[0].length) : "")),
  ].join("\n");
}
