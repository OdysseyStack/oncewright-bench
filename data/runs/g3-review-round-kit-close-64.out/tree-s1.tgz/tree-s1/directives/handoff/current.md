Branch `refunds-fixes` holds the fixes for CodeRabbit's refunds findings (commit ac15a6f). It isn't pushed and has no PR.

**Read first:**
- `refunds-review-rulings`: the note's `Restocking fee` row stays, per the plan. The user hasn't ruled on this yet.
- `export-check-needs-ledger-check`: here, a green `npm run check` proves only the tests.

**State:**
- Branch `refunds-fixes`, one commit ahead of `main`, working tree clean, not pushed.
- Commit ac15a6f: a partial refund's tax is now `percentOf` the summed lines (plan Slice 2 point 1), and SKU lookups use a `Set`. One test was added in `test/refunds.test.js`.
- Push, PR or merge only when the user asks.

**First:**
- Ask the user whether to push `refunds-fixes` and open a PR against `main`.

**Later:**
- Refunds Slice 3, partial refunds of discounted orders (`docs/plans/2026-09-30-refunds.md:37-51`).
  - `src/refunds.js:23` drops the throw.
  - `src/refunds.js:25-27`: fee, items and tax use each line's `net` from `computeTotals(...).lines`.
  - `src/refunds.js:35-38`: the note shows net prices.
  - `bin/refund-order.js`: `--code` works together with `--sku`.
  - The README drops its "not supported yet" note.
  - Build on top of `refunds-fixes`, or after it merges, because it changes the same lines.
- Slice 4 (tax rounding) waits on Finance. Until then, don't touch `percentOf`.

**Open flags:**
- CodeRabbit finding #2 (show `Items` net of the fee and drop the fee row) was rejected because the plan says otherwise. Ask the user whether they want the plan changed.
- `ledger-check` isn't installed, so the export import check has never run in this session.
