import assert from "node:assert/strict";
import test from "node:test";
import { config } from "../src/config.js";
import { validateOrder } from "../src/validate.js";

test("a good order has no problems", () => {
  assert.deepEqual(validateOrder({ items: [{ sku: "A", name: "A", unitPrice: 100, qty: 1 }] }), []);
});

test("each problem is named", () => {
  assert.deepEqual(validateOrder({}), ["the order has no items list"]);
  assert.deepEqual(validateOrder({ items: [] }), ["the order has no items"]);
  const problems = validateOrder({
    items: [
      { sku: "A", name: "A", unitPrice: 1.5, qty: 1 },
      { sku: "A", name: "", unitPrice: 100, qty: 0 },
    ],
  });
  assert.deepEqual(problems, [
    "item 1: unitPrice must be whole cents, 0 or more",
    "item 2: sku A appears twice",
    "item 2: no name",
    "item 2: qty must be a whole number, 1 or more",
  ]);
});

test("pickupAt is one of the pickup locations, spelled as the config spells it", () => {
  const item = { sku: "A", name: "A", unitPrice: 100, qty: 1 };
  assert.deepEqual(config.pickupLocations, ["Pier Road", "Northside"]);
  assert.deepEqual(validateOrder({ pickupAt: "Pier Road", items: [item] }), []);
  assert.deepEqual(validateOrder({ pickupAt: "Northside", items: [item] }), []);
  const known = '("Pier Road", "Northside")';
  assert.deepEqual(validateOrder({ pickupAt: "northside", items: [item] }), [`pickupAt "northside" is not a pickup location ${known}`]);
  assert.deepEqual(validateOrder({ pickupAt: "Downtown", items: [item] }), [`pickupAt "Downtown" is not a pickup location ${known}`]);
  assert.deepEqual(validateOrder({ pickupAt: "", items: [item] }), [`pickupAt "" is not a pickup location ${known}`]);
  assert.deepEqual(validateOrder({ pickupAt: true, items: [item] }), [`pickupAt true is not a pickup location ${known}`]);
});
