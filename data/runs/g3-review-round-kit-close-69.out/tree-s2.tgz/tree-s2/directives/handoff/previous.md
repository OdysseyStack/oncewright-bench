# Handoff — refunds-fixes committed (3435e57), not pushed; refunds Slice 3 next

**Read first:** `ledger-check-missing-locally`: `npm run check` goes green here without running the export import check.

**State:**
- On branch `refunds-fixes`, one commit above `main`: `3435e57` "Refund tax on the refunded lines' summed amount; Set lookup in linesFor". The tree is clean. No push and no PR yet; the user asked for neither.
- CodeRabbit's findings in `review/findings-refunds.md`: #1 (partial-refund tax per line) and #3 (Set in `linesFor`) are fixed. #2 (fold the restocking fee into `Items` on the note) was rejected because it conflicts with refunds plan Slice 2 point 5 and Slice 3 point 2.
- Tests: 31/31 pass.

**First:** surface the open flags below, then refunds Slice 3 (`docs/plans/2026-09-30-refunds.md`, "Slice 3": partial refunds of discounted orders).
- `src/refunds.js` 16–29 (`refundFor`): drop the throw at line 23 and use `computeTotals(...).lines[i].net` per line. Line 26 is the tax, now `percentOf(items, taxRate)` on the summed amount; keep it that way. The fee is 15% of `net`.
- `src/refunds.js` 32–49 (`renderRefundNote`): lines print at net, and `Items` is the sum of the nets.
- `bin/refund-order.js` (`--code` with `--sku`), README ("not supported yet" note), `test/refunds.test.js` (the discounted-partial throw test at the "is an error" case changes).
- Leave `percentOf` as it is (Slice 4, waiting on finance). Start with `/odyssey:prove-it` for test-first work.

**Later:** refunds Slice 4 (only when finance is ready); the other plans in `docs/plans/`.

**Open flags:**
- The user hasn't confirmed rejecting CodeRabbit finding #2. If they want it, the plan's Slice 2 point 5 and Slice 3 point 2 must change first.
- Push `refunds-fixes` / open a PR / merge: the user's call, not asked yet.
- Should Slice 3 build on `refunds-fixes` or on `main` after it merges? Ask before branching.
