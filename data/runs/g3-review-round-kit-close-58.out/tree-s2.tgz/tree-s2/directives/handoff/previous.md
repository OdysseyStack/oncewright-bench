# Handoff: refunds-fixes is committed (8c7c8d1), not pushed; refunds Slice 3 is next

**Read first:** `refund-note-fee-own-line`: why CodeRabbit's "fold the fee into Items" finding was rejected. `ledger-check-not-installed`: a green `npm run check` here covers the tests only.

**State:**
- On branch `refunds-fixes`, one commit ahead of `main` (8c7c8d1), clean tree. Not pushed, no PR. Push or open a PR only when the user asks.
- From `review/findings-refunds.md`, two of the three findings are fixed:
  - Partial-refund tax is now `percentOf` the refunded lines' sum (`src/refunds.js:25-27`), and a new test covers it in `test/refunds.test.js`.
  - `linesFor` uses a `Set`.
- Finding 2 was rejected (see memory above). The findings file is still in the repo.

**First:** ask the user what to do with `refunds-fixes` (push and open a PR, or merge it themselves) before starting new work on top of it.

**Later:**
1. Refunds plan Slice 3: partial refunds of discounted orders (`docs/plans/2026-09-30-refunds.md`, Slice 3 section).
   - It changes these files:
     - `src/refunds.js`: drop the throw at line ~21; line nets come from `computeTotals(...).lines`; the fee at line 24 becomes 15% of the net; the note rows at lines 36 and 38.
     - `test/refunds.test.js`
     - `bin/refund-order.js`: `--code` works with `--sku`.
     - `README.md:94-98`: drop the "not supported yet" sentence.
   - Start with `/odyssey:prove-it` (test first).
   - Keep tax on the *sum* of the refunded nets, as fixed today.
   - Don't touch `percentOf` rounding: that's Slice 4, held for finance's tax-filing amendment.
2. Slice 4 waits on finance. Don't start it.

**Open flags:**
- The user hasn't confirmed the rejection of CodeRabbit finding 2 (refund note layout).
- Slice 3 point 1 says "the tax on it", which could be read as per line. Today's fix and Slice 2 tax the sum, so confirm the sum reading with the user if it matters.
- Whether to delete `review/findings-refunds.md` now that it's been dealt with.
