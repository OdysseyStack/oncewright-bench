// Refunds: a whole order (the refund plan's Slice 1), or some of its lines (Slice 2), discounted or not (Slice 3).
import { config } from "./config.js";
import { formatMoney, percentOf, sumCents } from "./money.js";
import { computeTotals } from "./totals.js";

// The order's lines a refund covers, each with its net from computeTotals (its amount less its share
// of any discount): those whose SKUs are listed, or all of them.
const linesFor = (order, totals, skus) => {
  const lines = order.items.map((item, i) => ({ ...item, net: totals.lines[i].net }));
  if (skus === undefined) return lines;
  const wanted = new Set(skus);
  return lines.filter((line) => wanted.has(line.sku));
};

// What a refund pays back, in cents: { items, fee, shipping, tax, total }. options: the options the
// order was priced with (pickup, code), plus skus, the lines to refund (all of them when absent),
// and opened, the refunded lines that keep a restocking fee. Each line pays back its net.
export function refundFor(order, options = {}) {
  return refund(order, computeTotals(order, options), options);
}

function refund(order, t, options) {
  const { skus, opened = [] } = options;
  const unknown = [...(skus ?? []), ...opened].find((sku) => !order.items.some((item) => item.sku === sku));
  if (unknown !== undefined) throw new Error(`SKU not on the order: ${unknown}`);
  const lines = linesFor(order, t, skus);
  const whole = lines.length === order.items.length;
  const fee = sumCents(lines.filter((line) => opened.includes(line.sku)).map((line) => percentOf(line.net, config.restockingFee)));
  // The nets add up to subtotal - discount, so a whole refund pays back what the order charged.
  const items = sumCents(lines.map((line) => line.net));
  // Tax on the refunded lines' summed net, as computeTotals charges it, not summed per line.
  const tax = whole ? t.tax : percentOf(items, config.taxRate);
  const shipping = whole ? t.shipping : 0;
  return { items, fee, shipping, tax, total: items - fee + shipping + tax };
}

// The note the customer gets with a refund: the refunded lines at their net price, as the receipt
// prints them, then the totals.
export function renderRefundNote(order, options = {}) {
  const t = computeTotals(order, options);
  const r = refund(order, t, options);
  const rows = [
    ...linesFor(order, t, options.skus).map((line) => [`${line.qty} x ${line.name}`, line.net]),
    null,
    ...(r.fee ? [["Restocking fee", -r.fee]] : []),
    ["Items", r.items],
    ["Shipping", r.shipping],
    ["Tax", r.tax],
    ["Refund", r.total],
  ].map((row) => row && [row[0], formatMoney(row[1])]);
  const width = Math.max(...rows.filter(Boolean).map(([label, amount]) => label.length + amount.length)) + 2;
  return [
    `Refund for order ${order.id ?? "(no id)"}`,
    "",
    ...rows.map((row) => (row ? row[0] + row[1].padStart(width - row[0].length) : "")),
  ].join("\n");
}
