import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";

const cli = fileURLToPath(new URL("../bin/price-order.js", import.meta.url));
const example = fileURLToPath(new URL("../examples/order.json", import.meta.url));
const run = (...args) => spawnSync(process.execPath, [cli, ...args], { encoding: "utf8" });

test("prints the totals of an order file", () => {
  const { status, stdout } = run(example);
  assert.equal(status, 0);
  assert.equal(stdout, "Subtotal: $37.00\nShipping: $5.99\nTax: $2.96\nTotal: $45.95\n");
});

test("--code shows the discount; --pickup drops the shipping", () => {
  assert.equal(run(example, "--code", "SAVE10").stdout, "Subtotal: $37.00\nDiscount (SAVE10): -$3.70\nShipping: $5.99\nTax: $2.66\nTotal: $41.95\n");
  assert.match(run(example, "--pickup").stdout, /^Shipping: \$0\.00$/m);
});

test("--json prints the totals in cents", () => {
  const t = JSON.parse(run(example, "--json").stdout);
  assert.equal(t.subtotal, 3700);
  assert.equal(t.total, 4595);
  const coded = JSON.parse(run(example, "--json", "--code", "SAVE10").stdout);
  assert.deepEqual(coded.lines.map((l) => l.net), [2160, 1170]);
});

test("--json includes the order's note; the text output leaves it out", () => {
  assert.equal(JSON.parse(run(example, "--json").stdout).note, "Leave it at the side door");
  assert.doesNotMatch(run(example).stdout, /side door/);
  const dir = mkdtempSync(join(tmpdir(), "price-order-"));
  const plain = join(dir, "plain.json");
  const { note, ...rest } = JSON.parse(readFileSync(example, "utf8"));
  writeFileSync(plain, JSON.stringify(rest));
  assert.equal("note" in JSON.parse(run(plain, "--json").stdout), false);
  const long = join(dir, "long.json");
  writeFileSync(long, JSON.stringify({ ...rest, note: "x".repeat(201) }));
  const refused = run(long);
  assert.equal(refused.status, 1);
  assert.match(refused.stderr, /note is longer than 200 characters/);
  rmSync(dir, { recursive: true });
});

test("bad input: the usage, an unknown code, a bad order", () => {
  assert.match(run().stderr, /Usage: price-order/);
  const unknown = run(example, "--code", "FREE");
  assert.equal(unknown.status, 1);
  assert.match(unknown.stderr, /FREE/);
  assert.equal(run(fileURLToPath(new URL("../package.json", import.meta.url))).status, 1);
});
