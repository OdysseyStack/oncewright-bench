# Changelog

## Unreleased

- Pickup locations: an order's `pickupAt` names the counter it is collected from (`Pier Road` or
  `Northside`); it pays no shipping, and the receipt and the invoice say `Pickup at <location>`.
  `price-order --pickup-at <location>` sets it.
- The order export has a new last column, `pickup`: the order's `pickupAt`, or empty. The header is
  now `id,date,subtotal,discount,shipping,tax,total,pickup`.

## 0.7.0 (2026-10-04)

- Refunds of some of an order's lines, with a 15% restocking fee for opened items
  (`refund-order --sku`, `--opened`).
- With a discount code, the receipt and the invoice show each line after its share of the discount.
- `npm run check` runs the tests and the export import check before a commit.

## 0.6.0 (2026-09-22)

- Refund a whole order: `refundFor`, `renderRefundNote` and `refund-order`.

## 0.5.0 (2026-09-08)

- Split payments (`splitEvenly`, `splitByShares`) and the nightly accounting export
  (`export-orders`): one CSV row per order, `id,date,subtotal,discount,shipping,tax,total`.

## 0.4.0 (2026-08-25)

- Receipts with amounts in one column, and invoices for business customers.

## 0.3.0 (2026-08-11)

- The price-order CLI and order checks (`validateOrder`).

## 0.2.0 (2026-08-03)

- Line totals, discount codes, tax and shipping.
