# Handoff — refunds-fixes committed (CodeRabbit refunds findings dealt with), not pushed

**Read first:** `ledger-check-not-installed`: `npm run check` here runs only the tests; the export import check is skipped with a warning.

**State:**
- Branch `refunds-fixes`, one commit `677b1ed` on top of `main` (99fa4fd). Tree clean. Not pushed, no PR. Push or open a PR only if the user asks.
- From `review/findings-refunds.md`: #1 fixed (a partial refund's tax is now `percentOf(items, taxRate)` on the summed amount, with a 130-vs-131¢ test). #3 fixed (`linesFor` uses a `Set`). #2 rejected: the plan's Slice 2 point 5 asks for a separate negative `Restocking fee` note line.
- 31/31 tests pass.

**First:** ask the user whether to push `refunds-fixes` / open a PR, or merge it. Then refunds **Slice 3** (`docs/plans/2026-09-30-refunds.md`, section "Slice 3"):
- `src/refunds.js` `refundFor` ~lines 16–30: drop the discounted-partial throw (~line 23); each line pays back its `net` from `computeTotals(order, options).lines`; fee = 15% of `net`; tax on the refunded nets' sum (keep the summed form from 677b1ed, don't go back to per line).
- `renderRefundNote` ~lines 32–49: lines at net price, `Items` = sum of nets.
- `bin/refund-order.js` `--code` with `--sku`; README drops "not supported yet"; tests in `test/refunds.test.js` (the "partial refund of a discounted order is an error" assertion goes).
- Mark Slice 3 done in the plan's status line when finished.

**Trap:** `percentOf` floors (`src/money.js`) even though its comment says it rounds. Leave it: Slice 4 fixes it, held back for Finance's filing amendment.

**Later:** refunds Slice 4 (only when the user says Finance is ready), then the other plans in `docs/plans/`.

**Open flags:**
- Finding #2 rejected because it goes against the plan. If the user wants the fee folded into `Items`, the plan's Slice 2 point 5 has to change first.
- Should `review/findings-refunds.md` stay in the repo now that it's dealt with? (Not touched.)
