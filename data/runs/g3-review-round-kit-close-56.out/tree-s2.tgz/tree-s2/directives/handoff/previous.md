# Refunds review fixes committed on `refunds-fixes`; one CodeRabbit finding declined, awaiting the user's say

**Read first:** `ledger-check-missing`: `npm run check` here runs only the tests, not the export import check.

**State:** branch `refunds-fixes`, clean, one commit `ec8dccc` on top of `main`, not pushed and no PR.
Push or open a PR only when the user asks.

**First:** ask the user about the one finding in `review/findings-refunds.md` that wasn't taken
(the 2nd: show the refund note's `Items` after the restocking fee and drop the `Restocking fee` row).
It was declined because `docs/plans/2026-09-30-refunds.md` Slice 2 point 5 asks for the separate
negative fee line. If they want CodeRabbit's layout, the plan's Slice 2 point 5 and Slice 3 point 2
change first. After that, `src/refunds.js` `renderRefundNote` (lines ~32–49) and the note test plus
the CLI `Restocking fee` match in `test/refunds.test.js`. Keep `fee` in the `--json` output.

**Later:** refunds Slice 3 (partial refunds of discounted orders), per the plan. Slice 4 (rounding
in `percentOf`) stays parked until finance's filing amendment. Don't touch `percentOf`.

**Open flags:**
- Fee-row layout on the refund note: undecided (see First).
- Whether to push `refunds-fixes` and open a PR: not asked yet.
