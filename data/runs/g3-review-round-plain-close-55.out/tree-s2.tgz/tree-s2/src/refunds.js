// Refunds: a whole order (the refund plan's Slice 1), or some of its lines (Slices 2 and 3).
import { config } from "./config.js";
import { formatMoney, percentOf, sumCents } from "./money.js";
import { computeTotals } from "./totals.js";

// The order's lines a refund covers, as { item, net }: those whose SKUs are listed, or all of them.
// net is the line's amount less its share of any discount, from computeTotals's lines.
function linesFor(order, totals, skus) {
  const wanted = skus === undefined ? null : new Set(skus);
  return order.items
    .map((item, i) => ({ item, net: totals.lines[i].net }))
    .filter(({ item }) => wanted === null || wanted.has(item.sku));
}

// The lines a refund covers and what it pays back, in cents.
function refund(order, options) {
  const t = computeTotals(order, options);
  const { skus, opened = [] } = options;
  const unknown = [...(skus ?? []), ...opened].find((sku) => !order.items.some((item) => item.sku === sku));
  if (unknown !== undefined) throw new Error(`SKU not on the order: ${unknown}`);
  const lines = linesFor(order, t, skus);
  const whole = lines.length === order.items.length;
  const isOpened = new Set(opened);
  const fee = sumCents(lines.filter(({ item }) => isOpened.has(item.sku)).map(({ net }) => percentOf(net, config.restockingFee)));
  // Each line's net: the nets add up to the subtotal after the discount, so a whole refund pays
  // back what the order paid for its items.
  const items = sumCents(lines.map(({ net }) => net));
  // Tax on the lines' summed amount, as computeTotals charges it, not summed per line.
  const tax = whole ? t.tax : percentOf(items, config.taxRate);
  const shipping = whole ? t.shipping : 0;
  return { lines, amounts: { items, fee, shipping, tax, total: items - fee + shipping + tax } };
}

// What a refund pays back, in cents: { items, fee, shipping, tax, total }. options: the options the
// order was priced with (pickup, code), plus skus, the lines to refund (all of them when absent),
// and opened, the refunded lines that keep a restocking fee. With a code, each line pays back its
// net, its amount less its share of the discount, and an opened line's fee is 15% of its net.
export function refundFor(order, options = {}) {
  return refund(order, options).amounts;
}

// The note the customer gets with a refund: the refunded lines at their net price, then the totals.
export function renderRefundNote(order, options = {}) {
  const { lines, amounts: r } = refund(order, options);
  const rows = [
    ...lines.map(({ item, net }) => [`${item.qty} x ${item.name}`, net]),
    null,
    ...(r.fee ? [["Restocking fee", -r.fee]] : []),
    ["Items", r.items],
    ["Shipping", r.shipping],
    ["Tax", r.tax],
    ["Refund", r.total],
  ].map((row) => row && [row[0], formatMoney(row[1])]);
  const width = Math.max(...rows.filter(Boolean).map(([label, amount]) => label.length + amount.length)) + 2;
  return [
    `Refund for order ${order.id ?? "(no id)"}`,
    "",
    ...rows.map((row) => (row ? row[0] + row[1].padStart(width - row[0].length) : "")),
  ].join("\n");
}
