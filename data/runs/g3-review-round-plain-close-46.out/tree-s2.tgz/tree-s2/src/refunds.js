// Refunds: a whole order (the refund plan's Slice 1), or some of its lines (Slice 2), with or
// without a discount code (Slice 3).
import { config } from "./config.js";
import { formatMoney, percentOf, sumCents } from "./money.js";
import { computeTotals } from "./totals.js";

// The order's lines a refund covers, each { item, net }: those whose SKUs are listed, or all of
// them. net is the line's amount less its share of the order's discount, from computeTotals.
function linesFor(order, totals, skus) {
  const lines = order.items.map((item, i) => ({ item, net: totals.lines[i].net }));
  if (skus === undefined) return lines;
  const wanted = new Set(skus);
  return lines.filter(({ item }) => wanted.has(item.sku));
}

// What a refund pays back, in cents: { items, fee, shipping, tax, total }. options: the options the
// order was priced with (pickup, code), plus skus, the lines to refund (all of them when absent),
// and opened, the refunded lines that keep a restocking fee. Each line pays back its net amount;
// the tax is on the lines' summed net, as computeTotals charges it (per-line tax would lose a cent
// per line), so a whole refund pays back exactly what the order charged.
export function refundFor(order, options = {}) {
  const t = computeTotals(order, options);
  const { skus, opened = [] } = options;
  const unknown = [...(skus ?? []), ...opened].find((sku) => !order.items.some((item) => item.sku === sku));
  if (unknown !== undefined) throw new Error(`SKU not on the order: ${unknown}`);
  const lines = linesFor(order, t, skus);
  const whole = lines.length === order.items.length;
  const fee = sumCents(lines.filter(({ item }) => opened.includes(item.sku)).map(({ net }) => percentOf(net, config.restockingFee)));
  const items = sumCents(lines.map(({ net }) => net));
  const tax = percentOf(items, config.taxRate);
  const shipping = whole ? t.shipping : 0;
  return { items, fee, shipping, tax, total: items - fee + shipping + tax };
}

// The note the customer gets with a refund: the refunded lines at their net amounts (as the
// receipt shows them), then the totals. The lines add up to Items.
export function renderRefundNote(order, options = {}) {
  const r = refundFor(order, options);
  const rows = [
    ...linesFor(order, computeTotals(order, options), options.skus).map(({ item, net }) => [`${item.qty} x ${item.name}`, net]),
    null,
    ...(r.fee ? [["Restocking fee", -r.fee]] : []),
    ["Items", r.items],
    ["Shipping", r.shipping],
    ["Tax", r.tax],
    ["Refund", r.total],
  ].map((row) => row && [row[0], formatMoney(row[1])]);
  const width = Math.max(...rows.filter(Boolean).map(([label, amount]) => label.length + amount.length)) + 2;
  return [
    `Refund for order ${order.id ?? "(no id)"}`,
    "",
    ...rows.map((row) => (row ? row[0] + row[1].padStart(width - row[0].length) : "")),
  ].join("\n");
}
