import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { readFileSync } from "node:fs";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { config } from "../src/config.js";
import { exportCsv, exportRow, HEADER } from "../src/export.js";

const at = (p) => fileURLToPath(new URL(p, import.meta.url));

test("one row per order, with its options", () => {
  const order = { id: "A-1", date: "2026-09-01", code: "TAKE5", items: [{ sku: "A", name: "A", unitPrice: 2400, qty: 1 }] };
  assert.equal(exportRow(order), "A-1,2026-09-01,$24.00,$5.00,$5.99,$1.52,$26.51,");
  assert.equal(exportCsv([order]).split("\n")[0], "id,date,subtotal,discount,shipping,tax,total,pickup");
  assert.equal(HEADER, "id,date,subtotal,discount,shipping,tax,total,pickup");
});

test("export-orders writes the CSV for a folder of orders", () => {
  const r = spawnSync(process.execPath, [at("../bin/export-orders.js"), at("../examples/orders")], { encoding: "utf8" });
  assert.equal(r.status, 0, r.stderr);
  assert.equal(
    r.stdout,
    "id,date,subtotal,discount,shipping,tax,total,pickup\nA-1041,2026-09-02,$60.00,$6.00,$0.00,$4.32,$58.32,\nA-1042,2026-09-02,$45.00,$0.00,$0.00,$3.60,$48.60,Northside\n",
  );
});

test("the pickup column holds the order's pickupAt, after total, and the order pays no shipping", () => {
  const items = [{ sku: "A", name: "A", unitPrice: 1000, qty: 1 }];
  for (const pickupAt of config.pickupLocations) {
    const row = exportRow({ id: "A-2", date: "2026-10-10", pickupAt, items });
    assert.equal(row, `A-2,2026-10-10,$10.00,$0.00,$0.00,$0.80,$10.80,${pickupAt}`);
    assert.equal(row.split(",").length, HEADER.split(",").length);
  }
  assert.equal(exportRow({ id: "A-3", date: "2026-10-10", items }), "A-3,2026-10-10,$10.00,$0.00,$5.99,$0.80,$16.79,");
  const csv = exportCsv([{ id: "A-2", date: "2026-10-10", pickupAt: "Pier Road", items }, { id: "A-3", date: "2026-10-10", items }]);
  assert.equal(csv, `${HEADER}\nA-2,2026-10-10,$10.00,$0.00,$0.00,$0.80,$10.80,Pier Road\nA-3,2026-10-10,$10.00,$0.00,$5.99,$0.80,$16.79,\n`);
});

test("the example order A-1042 is picked up at Northside", () => {
  const order = JSON.parse(readFileSync(at("../examples/orders/A-1042.json"), "utf8"));
  assert.equal(order.pickupAt, "Northside");
});
