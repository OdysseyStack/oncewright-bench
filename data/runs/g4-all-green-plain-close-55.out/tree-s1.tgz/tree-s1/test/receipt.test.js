import assert from "node:assert/strict";
import test from "node:test";
import { renderInvoice } from "../src/invoice.js";
import { renderReceipt } from "../src/receipt.js";

const order = {
  items: [
    { sku: "BEANS-1KG", name: "House beans 1kg", unitPrice: 2400, qty: 1 },
    { sku: "FILTER-100", name: "Paper filters x100", unitPrice: 650, qty: 2 },
  ],
};

test("the receipt lists each line, then the totals, amounts in one column", () => {
  assert.equal(
    renderReceipt(order),
    [
      "1 x House beans 1kg @ $24.00    $24.00",
      "2 x Paper filters x100 @ $6.50  $13.00",
      "",
      "Subtotal                        $37.00",
      "Shipping                         $5.99",
      "Tax                              $2.96",
      "Total                           $45.95",
    ].join("\n"),
  );
});

test("with a code, each line shows its price after the discount", () => {
  assert.equal(
    renderReceipt(order, { code: "SAVE10" }),
    [
      "1 x House beans 1kg @ $24.00    $21.60",
      "2 x Paper filters x100 @ $6.50  $11.70",
      "",
      "Subtotal                        $33.30",
      "Shipping                         $5.99",
      "Tax                              $2.66",
      "Total                           $41.95",
      "",
      "Code SAVE10 saved you $3.70",
    ].join("\n"),
  );
});

test("a note is the receipt's last line, after a blank line", () => {
  const noted = { ...order, note: "Leave it at the side door" };
  assert.equal(renderReceipt(noted), `${renderReceipt(order)}\n\nNote: Leave it at the side door`);
  assert.equal(
    renderReceipt(noted, { code: "SAVE10" }),
    `${renderReceipt(order, { code: "SAVE10" })}\n\nNote: Leave it at the side door`,
  );
  assert.ok(renderReceipt(noted).endsWith("Total                           $45.95\n\nNote: Leave it at the side door"));
  assert.equal(renderReceipt({ ...order, note: "" }), renderReceipt(order));
});

test("the invoice leaves the note out", () => {
  const invoice = { number: "INV-1", date: "2026-09-01", customer: "Harbor Cafe" };
  assert.equal(renderInvoice({ ...order, note: "Ring twice" }, invoice), renderInvoice(order, invoice));
});
