import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { refundFor, renderRefundNote } from "../src/refunds.js";

const at = (p) => fileURLToPath(new URL(p, import.meta.url));
const order = {
  id: "A-1040",
  items: [
    { sku: "BEANS-1KG", name: "House beans 1kg", unitPrice: 2400, qty: 1 },
    { sku: "FILTER-100", name: "Paper filters x100", unitPrice: 650, qty: 2 },
  ],
};

test("a refund pays back the whole order", () => {
  assert.deepEqual(refundFor(order), { items: 3700, fee: 0, shipping: 599, tax: 296, total: 4595 });
  assert.deepEqual(refundFor(order, { code: "SAVE10" }), { items: 3330, fee: 0, shipping: 599, tax: 266, total: 4195 });
});

test("a refund of some lines pays back their amount and its tax, and no shipping", () => {
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"] }), { items: 1300, fee: 0, shipping: 0, tax: 104, total: 1404 });
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100", "BEANS-1KG"] }), refundFor(order));
});

test("a partial refund's tax is on the refunded lines' summed amount, as the order charged it", () => {
  const odd = {
    items: [
      { sku: "A", name: "A", unitPrice: 619, qty: 1 },
      { sku: "B", name: "B", unitPrice: 1019, qty: 1 },
      { sku: "C", name: "C", unitPrice: 500, qty: 1 },
    ],
  };
  // 8% of $16.38 is $1.3104, so $1.31; per line it would be $0.49 + $0.81 = $1.30.
  assert.deepEqual(refundFor(odd, { skus: ["A", "B"] }), { items: 1638, fee: 0, shipping: 0, tax: 131, total: 1769 });
});

test("an opened line keeps a 15% restocking fee", () => {
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"] }), { items: 2400, fee: 360, shipping: 0, tax: 192, total: 2232 });
});

test("a SKU not on the order is an error", () => {
  assert.throws(() => refundFor(order, { skus: ["TEA-50"] }), /TEA-50/);
  assert.throws(() => refundFor(order, { skus: ["BEANS-1KG"], opened: ["TEA-50"] }), /TEA-50/);
});

test("a partial refund of a discounted order pays back each line's net and the tax on it", () => {
  // SAVE10 takes $3.70 off $37.00: $2.40 off the beans (net $21.60), $1.30 off the filters ($11.70).
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"], code: "SAVE10" }), { items: 1170, fee: 0, shipping: 0, tax: 93, total: 1263 });
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], code: "SAVE10" }), { items: 2160, fee: 0, shipping: 0, tax: 172, total: 2332 });
  // Every line, listed or not, gives the same amounts as Slice 1's whole refund.
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG", "FILTER-100"], code: "SAVE10" }), refundFor(order, { code: "SAVE10" }));
  const fixed = refundFor(order, { skus: ["FILTER-100"], code: "TAKE5" });
  // TAKE5's $5.00 splits $3.24 / $1.76 by amount, so the filters' net is $11.24.
  assert.deepEqual(fixed, { items: 1124, fee: 0, shipping: 0, tax: 89, total: 1213 });
});

test("a partial refund of a discounted order taxes the summed nets, not each line", () => {
  const odd = {
    items: [
      { sku: "A", name: "A", unitPrice: 688, qty: 1 },
      { sku: "B", name: "B", unitPrice: 1132, qty: 1 },
      { sku: "C", name: "C", unitPrice: 556, qty: 1 },
    ],
  };
  // SAVE10's $2.37 off $23.76 leaves nets of $6.19, $10.19 and $5.01; 8% of $16.38 is $1.31, where
  // per line it would be $0.49 + $0.81 = $1.30.
  assert.deepEqual(refundFor(odd, { skus: ["A", "B"], code: "SAVE10" }), { items: 1638, fee: 0, shipping: 0, tax: 131, total: 1769 });
});

test("an opened line of a discounted order keeps 15% of its net", () => {
  // 15% of $21.60 is $3.24; the tax is on the $21.60 the line paid, as before.
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"], code: "SAVE10" }), { items: 2160, fee: 324, shipping: 0, tax: 172, total: 2008 });
});

test("the refund note shows each part", () => {
  assert.equal(
    renderRefundNote(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"] }),
    "Refund for order A-1040\n\n1 x House beans 1kg  $24.00\n\nRestocking fee       -$3.60\nItems                $24.00\nShipping              $0.00\nTax                   $1.92\nRefund               $22.32",
  );
});

test("the refund note of a discounted order prints each line at its net price", () => {
  assert.equal(
    renderRefundNote(order, { skus: ["FILTER-100"], code: "SAVE10" }),
    "Refund for order A-1040\n\n2 x Paper filters x100  $11.70\n\nItems                   $11.70\nShipping                 $0.00\nTax                      $0.93\nRefund                  $12.63",
  );
  const whole = renderRefundNote(order, { code: "SAVE10", opened: ["BEANS-1KG"] });
  assert.match(whole, /^1 x House beans 1kg +\$21\.60$/m);
  assert.match(whole, /^2 x Paper filters x100 +\$11\.70$/m);
  assert.match(whole, /^Restocking fee +-\$3\.24$/m);
  assert.match(whole, /^Items +\$33\.30$/m);
});

test("refund-order prints the note, or --json the amounts", () => {
  const cli = (...args) => spawnSync(process.execPath, [at("../bin/refund-order.js"), ...args], { encoding: "utf8" });
  assert.match(cli(at("../examples/order.json")).stdout, /^Refund +\$45\.95$/m);
  assert.deepEqual(JSON.parse(cli(at("../examples/order.json"), "--json").stdout), { items: 3700, fee: 0, shipping: 599, tax: 296, total: 4595 });
  assert.match(cli(at("../examples/order.json"), "--sku", "BEANS-1KG", "--opened", "BEANS-1KG").stdout, /^Restocking fee +-\$3\.60$/m);
  const discounted = cli(at("../examples/order.json"), "--code", "SAVE10", "--sku", "FILTER-100");
  assert.equal(discounted.status, 0);
  assert.match(discounted.stdout, /^2 x Paper filters x100 +\$11\.70$/m);
  assert.match(discounted.stdout, /^Refund +\$12\.63$/m);
  assert.deepEqual(JSON.parse(cli(at("../examples/order.json"), "--json", "--code", "SAVE10", "--sku", "FILTER-100").stdout), { items: 1170, fee: 0, shipping: 0, tax: 93, total: 1263 });
  const unknown = cli(at("../examples/order.json"), "--sku", "TEA-50");
  assert.equal(unknown.status, 1);
  assert.match(unknown.stderr, /TEA-50/);
  assert.equal(cli().status, 1);
});
