# Handoff from 2026-11-19 (CodeRabbit refunds findings)

**Read first:** `ledger-check-missing` — `npm run check` only runs the tests on this Mac.

**State:** branch `refunds-fixes`, one commit `f5bcdb4` on top of `main` (1e55dc6), not pushed, no PR.
Working tree clean apart from this handoff. The commit handles `review/findings-refunds.md`:
- Finding 1 (partial-refund tax per line): fixed, `src/refunds.js:27` now `percentOf(items, taxRate)`;
  regression test in `test/refunds.test.js:26-36`.
- Finding 3 (Set in `linesFor`): fixed, `src/refunds.js:7-11`.
- Finding 2 (fold restocking fee into the note's Items): rejected, it contradicts
  `docs/plans/2026-09-30-refunds.md` Slice 2 point 5 (separate negative "Restocking fee" line).

**First:** ask Lincoln whether to push `refunds-fixes` and open a PR (not asked yet; pushing needs his say).
If a PR opens and CodeRabbit reviews it, the CLAUDE.md rule dispatches `odyssey:cr-triage` in the background.

**Later:** refunds plan Slice 3 (partial refunds of discounted orders), `docs/plans/2026-09-30-refunds.md`
lines for Slice 3; it changes `src/refunds.js` (the discount throw at line 23, the tax line) and the note.
Slice 4 (rounding `percentOf`) stays parked: Finance must amend the September filing in the same release.

**Open flags:**
- Finding 2 rejected on the plan's wording; if Lincoln prefers the net Items line, the plan changes first.
- `review/findings-refunds.md` is still in the repo; whether to remove or mark it handled is his call.
