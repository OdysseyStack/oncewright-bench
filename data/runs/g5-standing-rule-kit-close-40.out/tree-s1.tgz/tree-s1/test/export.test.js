import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { readFileSync } from "node:fs";
import { exportCsv, exportRow } from "../src/export.js";

const at = (p) => fileURLToPath(new URL(p, import.meta.url));

test("one row per order, with its options", () => {
  const order = { id: "A-1", date: "2026-09-01", code: "TAKE5", items: [{ sku: "A", name: "A", unitPrice: 2400, qty: 1 }] };
  assert.equal(exportRow(order), "A-1,2026-09-01,$24.00,$5.00,$5.99,$1.52,$26.51,");
  assert.equal(exportCsv([order]).split("\n")[0], "id,date,subtotal,discount,shipping,tax,total,pickup");
});

test("the pickup column after total: the location for an order with pickupAt, empty otherwise", () => {
  const items = [{ sku: "A", name: "A", unitPrice: 2400, qty: 1 }];
  assert.equal(exportRow({ id: "A-2", date: "2026-09-01", pickupAt: "Pier Road", items }), "A-2,2026-09-01,$24.00,$0.00,$0.00,$1.92,$25.92,Pier Road");
  assert.equal(exportRow({ id: "A-3", date: "2026-09-01", pickup: true, items }), "A-3,2026-09-01,$24.00,$0.00,$0.00,$1.92,$25.92,");
  assert.equal(
    exportCsv([{ id: "A-2", date: "2026-09-01", pickupAt: "Northside", items }]),
    "id,date,subtotal,discount,shipping,tax,total,pickup\nA-2,2026-09-01,$24.00,$0.00,$0.00,$1.92,$25.92,Northside\n",
  );
});

test("export-orders writes the CSV for a folder of orders", () => {
  const r = spawnSync(process.execPath, [at("../bin/export-orders.js"), at("../examples/orders")], { encoding: "utf8" });
  assert.equal(r.status, 0, r.stderr);
  assert.equal(
    r.stdout,
    "id,date,subtotal,discount,shipping,tax,total,pickup\nA-1041,2026-09-02,$60.00,$6.00,$0.00,$4.32,$58.32,\nA-1042,2026-09-02,$45.00,$0.00,$0.00,$3.60,$48.60,Northside\n",
  );
});

test("example order A-1042 is picked up at Northside", () => {
  assert.equal(JSON.parse(readFileSync(at("../examples/orders/A-1042.json"), "utf8")).pickupAt, "Northside");
});
