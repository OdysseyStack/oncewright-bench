// Refunds: a whole order (the refund plan's Slice 1), or some of its lines (Slice 2), with or without
// a discount code (Slice 3).
import { config } from "./config.js";
import { formatMoney, percentOf, sumCents } from "./money.js";
import { computeTotals } from "./totals.js";

// The order's lines a refund covers, as computeTotals(order, options).lines gives them ({ sku, amount,
// discount, net }), with each item: those whose SKUs are listed, or all of them.
const linesFor = (order, t, skus) => {
  const lines = order.items.map((item, i) => ({ ...t.lines[i], item }));
  if (skus === undefined) return lines;
  const wanted = new Set(skus);
  return lines.filter((line) => wanted.has(line.sku));
};

// What a refund pays back, in cents: { items, fee, shipping, tax, total }. options: the options the
// order was priced with (pickup, code), plus skus, the lines to refund (all of them when absent),
// and opened, the refunded lines that keep a restocking fee. Each line pays back its net: its amount
// less its share of any discount, so a whole refund pays back what the order charged.
export function refundFor(order, options = {}) {
  const t = computeTotals(order, options);
  const { skus, opened = [] } = options;
  const unknown = [...(skus ?? []), ...opened].find((sku) => !order.items.some((item) => item.sku === sku));
  if (unknown !== undefined) throw new Error(`SKU not on the order: ${unknown}`);
  const lines = linesFor(order, t, skus);
  const whole = lines.length === order.items.length;
  const fee = sumCents(lines.filter((line) => opened.includes(line.sku)).map((line) => percentOf(line.net, config.restockingFee)));
  // The nets add up to subtotal - discount (allocate() sees to it), so a whole refund's items match the order's.
  const items = sumCents(lines.map((line) => line.net));
  // The tax on the summed amount, as computeTotals charges it: per-line tax would lose a cent per line.
  const tax = whole ? t.tax : percentOf(items, config.taxRate);
  const shipping = whole ? t.shipping : 0;
  return { items, fee, shipping, tax, total: items - fee + shipping + tax };
}

// The note the customer gets with a refund: the refunded lines, each at its net price as on the
// receipt, then the totals.
export function renderRefundNote(order, options = {}) {
  const r = refundFor(order, options);
  const t = computeTotals(order, options);
  const rows = [
    ...linesFor(order, t, options.skus).map(({ item, net }) => [`${item.qty} x ${item.name}`, net]),
    null,
    ...(r.fee ? [["Restocking fee", -r.fee]] : []),
    ["Items", r.items],
    ["Shipping", r.shipping],
    ["Tax", r.tax],
    ["Refund", r.total],
  ].map((row) => row && [row[0], formatMoney(row[1])]);
  const width = Math.max(...rows.filter(Boolean).map(([label, amount]) => label.length + amount.length)) + 2;
  return [
    `Refund for order ${order.id ?? "(no id)"}`,
    "",
    ...rows.map((row) => (row ? row[0] + row[1].padStart(width - row[0].length) : "")),
  ].join("\n");
}
