# Handoff: CodeRabbit refunds findings fixed on `refunds-fixes`, not pushed

**Read first:** `ledger-check-missing`: `npm run check` passes here without running the export import check.

**State:**
- Branch `refunds-fixes` (from `main`), one commit `d92259c` "Refund the tax on some lines on their summed amount". Clean tree. Not pushed, and no PR yet. Push or open a PR only if the user asks.
- From `review/findings-refunds.md`: finding 1 is fixed. `src/refunds.js` `refundFor` now takes partial-refund tax as `percentOf(items, taxRate)` on the summed amount, per plan Slice 2 point 1. A new test in `test/refunds.test.js` covers $6.19 + $10.19 (refunds $1.31 tax, where the old code gave $1.30). Finding 3 is fixed: `linesFor` uses a `Set`.
- Finding 2 was **not** taken (fold the restocking fee into the note's `Items` line and drop the `Restocking fee` row). It conflicts with `docs/plans/2026-09-30-refunds.md` Slice 2 point 5 (a separate negative fee line) and the Slice 3 point 2 layout.
- `npm run check`: 31/31 tests pass. The export check was skipped because ledger-check is missing. The export wasn't touched.

**First:** ask the user whether to push `refunds-fixes` and open a PR into `main`. If they say yes, CLAUDE.md's rule dispatches `odyssey:cr-triage` in the background after the push.

**Later:** refunds plan Slice 3 (partial refunds of discounted orders), `docs/plans/2026-09-30-refunds.md` §Slice 3. It touches `src/refunds.js:19-22` (the discount-code throw, and items/fee/tax from `computeTotals(...).lines` nets) and the note in `renderRefundNote`. Slice 4 (tax rounding) waits on Finance: leave `percentOf` alone.

**Open flags:**
- Finding 2: the user hasn't said whether they want the fee folded into `Items` on the refund note. If yes, the plan's Slice 2 point 5 has to be changed first, then the code and the note test.
