Refunds fixes from CodeRabbit are committed on `refunds-fixes` (74b51f6). Not pushed, no PR. Finding 2 is still waiting on Lincoln.

**Read first:** `ledger-check-not-installed`: `npm run check` here runs only the tests, so the export import check gets skipped (say so in reports).

**State:** branch `refunds-fixes`, clean, 1 commit ahead of `main`, unpushed. Push it or open a PR only when Lincoln asks (no PR is open, so the auto-push rule doesn't apply).

**Done this session** (`review/findings-refunds.md`, 3 findings):
- 1 accepted: a partial refund's tax is now `percentOf` the refunded lines' sum (`src/refunds.js` ~line 27). This matches refunds plan Slice 2 point 1. The new test is in `test/refunds.test.js` ("a partial refund's tax…").
- 3 accepted: `linesFor` uses a `Set` (`src/refunds.js` lines 7-11).
- 2 rejected: fold the restocking fee into `Items` and drop the fee row. It conflicts with `docs/plans/2026-09-30-refunds.md` Slice 2 point 5 (separate negative `Restocking fee` line) and Slice 3 point 2 (`Items` = sum of line amounts).

**First:** ask Lincoln whether to push `refunds-fixes` / open a PR. Also ask about finding 2 (below).

**Later:** refunds plan Slice 3 (partial refunds of discounted orders): `src/refunds.js` `refundFor` + `renderRefundNote`, `bin/refund-order.js`, README, `test/refunds.test.js`. Slice 4 (tax rounding in `percentOf`) stays parked until finance amends the September filing.

**Open flags:**
- Finding 2: if Lincoln wants CodeRabbit's note layout (Items after the fee, no fee row), the refunds plan has to change first, then the note and its test.
