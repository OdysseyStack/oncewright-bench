// Refunds: a whole order (the refund plan's Slice 1), or some of its lines (Slice 2), with or
// without a discount code (Slice 3).
import { config } from "./config.js";
import { formatMoney, percentOf, sumCents } from "./money.js";
import { computeTotals } from "./totals.js";

// The order's lines a refund covers, each with its net (its amount less its share of any
// discount, from computeTotals): those whose SKUs are listed, or all of them.
const linesFor = (order, t, skus) => {
  const wanted = skus === undefined ? null : new Set(skus);
  return order.items.map((item, i) => ({ item, net: t.lines[i].net })).filter(({ item }) => !wanted || wanted.has(item.sku));
};

// What a refund pays back, in cents: { items, fee, shipping, tax, total }. options: the options the
// order was priced with (pickup, code), plus skus, the lines to refund (all of them when absent),
// and opened, the refunded lines that keep a restocking fee. Each line pays back its net, so a
// whole refund pays back what the order charged.
export function refundFor(order, options = {}) {
  const t = computeTotals(order, options);
  return refundOf(order, t, options);
}

function refundOf(order, t, { skus, opened = [] }) {
  const unknown = [...(skus ?? []), ...opened].find((sku) => !order.items.some((item) => item.sku === sku));
  if (unknown !== undefined) throw new Error(`SKU not on the order: ${unknown}`);
  const lines = linesFor(order, t, skus);
  const whole = lines.length === order.items.length;
  const fee = sumCents(lines.filter(({ item }) => opened.includes(item.sku)).map(({ net }) => percentOf(net, config.restockingFee)));
  // The nets add up to subtotal - discount, so a whole refund's items and tax are the order's.
  const items = sumCents(lines.map(({ net }) => net));
  // Tax on the lines' summed net, as computeTotals charges it, not summed per line.
  const tax = percentOf(items, config.taxRate);
  const shipping = whole ? t.shipping : 0;
  return { items, fee, shipping, tax, total: items - fee + shipping + tax };
}

// The note the customer gets with a refund: the refunded lines at their net price, as the receipt
// prints them, then the totals.
export function renderRefundNote(order, options = {}) {
  const t = computeTotals(order, options);
  const r = refundOf(order, t, options);
  const rows = [
    ...linesFor(order, t, options.skus).map(({ item, net }) => [`${item.qty} x ${item.name}`, net]),
    null,
    ...(r.fee ? [["Restocking fee", -r.fee]] : []),
    ["Items", r.items],
    ["Shipping", r.shipping],
    ["Tax", r.tax],
    ["Refund", r.total],
  ].map((row) => row && [row[0], formatMoney(row[1])]);
  const width = Math.max(...rows.filter(Boolean).map(([label, amount]) => label.length + amount.length)) + 2;
  return [
    `Refund for order ${order.id ?? "(no id)"}`,
    "",
    ...rows.map((row) => (row ? row[0] + row[1].padStart(width - row[0].length) : "")),
  ].join("\n");
}
