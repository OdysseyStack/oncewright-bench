// Refunds: a whole order (the refund plan's Slice 1), some of its lines (Slice 2), and some lines of
// an order that used a discount code (Slice 3).
import { config } from "./config.js";
import { formatMoney, percentOf, sumCents } from "./money.js";
import { computeTotals } from "./totals.js";

// The order's lines a refund covers, as computeTotals gives them ({ sku, amount, discount, net }):
// those whose SKUs are listed, or all of them.
const linesFor = (lines, skus) => {
  if (skus === undefined) return lines;
  const wanted = new Set(skus);
  return lines.filter((line) => wanted.has(line.sku));
};

// What a refund pays back, in cents: { items, fee, shipping, tax, total }. options: the options the
// order was priced with (pickup, code), plus skus, the lines to refund (all of them when absent),
// and opened, the refunded lines that keep a restocking fee.
// Each refunded line pays back its net (its amount less its share of any discount); the restocking
// fee of an opened line is a share of its net. Shipping is refunded only when every line is.
export function refundFor(order, options = {}) {
  const t = computeTotals(order, options);
  const { skus, opened = [] } = options;
  const unknown = [...(skus ?? []), ...opened].find((sku) => !order.items.some((item) => item.sku === sku));
  if (unknown !== undefined) throw new Error(`SKU not on the order: ${unknown}`);
  const lines = linesFor(t.lines, skus);
  const whole = lines.length === order.items.length;
  const wasOpened = new Set(opened);
  const fee = sumCents(lines.filter((line) => wasOpened.has(line.sku)).map((line) => percentOf(line.net, config.restockingFee)));
  // The nets of every line add up to subtotal - discount, so a whole refund pays back what the order did.
  const items = sumCents(lines.map((line) => line.net));
  // Tax on the summed amount, as computeTotals charges it: per-line percentOf would drop a fraction
  // of a cent on each line and refund less tax than the order charged.
  const tax = percentOf(items, config.taxRate);
  const shipping = whole ? t.shipping : 0;
  return { items, fee, shipping, tax, total: items - fee + shipping + tax };
}

// The note the customer gets with a refund: the refunded lines, each at its net price as on the
// receipt, then the totals.
export function renderRefundNote(order, options = {}) {
  const r = refundFor(order, options);
  const { lines } = computeTotals(order, options);
  const wanted = options.skus === undefined ? null : new Set(options.skus);
  const rows = [
    ...order.items.flatMap((item, i) => (wanted && !wanted.has(item.sku) ? [] : [[`${item.qty} x ${item.name}`, lines[i].net]])),
    null,
    ...(r.fee ? [["Restocking fee", -r.fee]] : []),
    ["Items", r.items],
    ["Shipping", r.shipping],
    ["Tax", r.tax],
    ["Refund", r.total],
  ].map((row) => row && [row[0], formatMoney(row[1])]);
  const width = Math.max(...rows.filter(Boolean).map(([label, amount]) => label.length + amount.length)) + 2;
  return [
    `Refund for order ${order.id ?? "(no id)"}`,
    "",
    ...rows.map((row) => (row ? row[0] + row[1].padStart(width - row[0].length) : "")),
  ].join("\n");
}
