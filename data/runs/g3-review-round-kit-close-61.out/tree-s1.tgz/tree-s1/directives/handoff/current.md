# Handoff: CodeRabbit's refunds findings are fixed on `refunds-fixes`

**Read first:**
- `refunds-coderabbit-rulings`: the fee-row finding was rejected because of README.md's bookkeeper rule; carry the summed-tax rule into Slice 3.
- `ledger-check-not-installed`: `npm run check` exits 0 even when the export import check is skipped.

**State:**
- On branch `refunds-fixes`, commit `a563248` ("Refunds: tax a partial refund on the lines' summed amount"). Not pushed, and there's no PR.
- Untracked: `review/findings-refunds.md.resolved`, the ruling on each finding (2 accepted, 1 rejected).
- 31 of 31 tests pass. The export import check didn't run because ledger-check isn't installed.
- Git rule: push, open a PR or merge only when the user asks.

**First:** ask the user whether to push `refunds-fixes` and open a PR against `main`.
- If yes, the PR description takes its what and why from `a563248`'s message.
- Once CodeRabbit has reviewed the PR, run `/odyssey:cr-triage <PR#>`.

**Later:** refunds Slice 3 (`docs/plans/2026-09-30-refunds.md`, "Slice 3"): partial refunds of discounted orders.
- Changes `src/refunds.js` `refundFor` (around lines 16-30) and `renderRefundNote`, `bin/refund-order.js`, the README's refunds paragraph (around lines 94-98) and `test/refunds.test.js`.
- Take the tax on the sum of the refunded lines' nets.
- Keep the `Restocking fee` row in the note.
- Leave `percentOf` flooring alone; changing it is Slice 4.

**Open flags:**
- Push, and a PR for `refunds-fixes`: the user hasn't decided.
- Commit `review/findings-refunds.md.resolved` (the findings file it sits beside is tracked) or leave it untracked: the user hasn't said.
- The export import check hasn't been verified on this machine (ledger-check is missing).
