# Handoff: refunds CodeRabbit fixes, committed on `refunds-fixes`

**Read first:** `refunds-cr-rulings` (how each finding was ruled, and why the note layout stays);
`ledger-check-not-installed` (the gate skips the export check here).

**State:**
- Branch `refunds-fixes`, one commit `50fbff7` on top of `main` (99fa4fd). It is not pushed and has no PR.
- Untracked: `review/findings-refunds.md.resolved`, the triage record. It was left out of the commit on purpose.
- Standing rule: commit, push, branch or PR only when the user asks (`.claude/rules/odyssey/primary.md`).

**First:** ask the user whether to push `refunds-fixes` and open a PR, or merge it some other way. Don't do either unasked.
- The fix is in `src/refunds.js`, lines 7-11 (`linesFor` with a Set) and line 26 (`tax = whole ? t.tax : percentOf(items, config.taxRate)`).
- The new test is in `test/refunds.test.js`, "a partial refund's tax is charged on the lines' summed amount".

**Later:** refunds Slice 3, partial refunds of discounted orders (`docs/plans/2026-09-30-refunds.md`, Slice 3).

**Open flags:**
- Slice 3 point 1 says each refunded line pays back "the tax on it at the tax rate", which reads as tax per line. Slice 2 point 1 and the fix
  just made compute tax on the summed amount, to match `computeTotals`. Ask the user which one Slice 3 means before building it.
- Should `review/findings-refunds.md.resolved` be committed or stay untracked? The user hasn't said.
