import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { refundFor, renderRefundNote } from "../src/refunds.js";

const at = (p) => fileURLToPath(new URL(p, import.meta.url));
const order = {
  id: "A-1040",
  items: [
    { sku: "BEANS-1KG", name: "House beans 1kg", unitPrice: 2400, qty: 1 },
    { sku: "FILTER-100", name: "Paper filters x100", unitPrice: 650, qty: 2 },
  ],
};

test("a refund pays back the whole order", () => {
  assert.deepEqual(refundFor(order), { items: 3700, fee: 0, shipping: 599, tax: 296, total: 4595 });
  assert.deepEqual(refundFor(order, { code: "SAVE10" }), { items: 3330, fee: 0, shipping: 599, tax: 266, total: 4195 });
});

test("a refund of some lines pays back their amount and its tax, and no shipping", () => {
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"] }), { items: 1300, fee: 0, shipping: 0, tax: 104, total: 1404 });
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100", "BEANS-1KG"] }), refundFor(order));
});

test("a refund of some lines takes the tax on their summed amount, as the order charged it", () => {
  const three = {
    items: [
      { sku: "A", name: "A", unitPrice: 619, qty: 1 },
      { sku: "B", name: "B", unitPrice: 1019, qty: 1 },
      { sku: "C", name: "C", unitPrice: 2400, qty: 1 },
    ],
  };
  // 8% of $16.38 is $1.31; 8% of each line, summed, would be $0.49 + $0.81 = $1.30.
  assert.deepEqual(refundFor(three, { skus: ["A", "B"] }), { items: 1638, fee: 0, shipping: 0, tax: 131, total: 1769 });
});

test("an opened line keeps a 15% restocking fee", () => {
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"] }), { items: 2400, fee: 360, shipping: 0, tax: 192, total: 2232 });
});

test("a SKU not on the order is an error", () => {
  assert.throws(() => refundFor(order, { skus: ["TEA-50"] }), /TEA-50/);
});

test("a partial refund of a discounted order pays back each line's net and the tax on it", () => {
  // SAVE10 takes $3.70 off: $2.40 from the beans, $1.30 from the filters.
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"], code: "SAVE10" }), { items: 1170, fee: 0, shipping: 0, tax: 93, total: 1263 });
  // TAKE5's $5.00 splits $3.24 / $1.76: the left-over cent goes to the filters, and the nets add up to $32.00.
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"], code: "TAKE5" }), { items: 1124, fee: 0, shipping: 0, tax: 89, total: 1213 });
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], code: "TAKE5" }), { items: 2076, fee: 0, shipping: 0, tax: 166, total: 2242 });
});

test("an opened line of a discounted order keeps 15% of its net", () => {
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"], code: "SAVE10" }), { items: 2160, fee: 324, shipping: 0, tax: 172, total: 2008 });
});

test("refunding every line of a discounted order gives the whole refund", () => {
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100", "BEANS-1KG"], code: "SAVE10" }), refundFor(order, { code: "SAVE10" }));
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100", "BEANS-1KG"], code: "TAKE5" }), refundFor(order, { code: "TAKE5" }));
});

test("the refund note shows each part", () => {
  assert.equal(
    renderRefundNote(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"] }),
    "Refund for order A-1040\n\n1 x House beans 1kg  $24.00\n\nRestocking fee       -$3.60\nItems                $24.00\nShipping              $0.00\nTax                   $1.92\nRefund               $22.32",
  );
});

test("the refund note of a discounted order prints each line at its net price", () => {
  assert.equal(
    renderRefundNote(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"], code: "SAVE10" }),
    "Refund for order A-1040\n\n1 x House beans 1kg  $21.60\n\nRestocking fee       -$3.24\nItems                $21.60\nShipping              $0.00\nTax                   $1.72\nRefund               $20.08",
  );
});

test("refund-order prints the note, or --json the amounts", () => {
  const cli = (...args) => spawnSync(process.execPath, [at("../bin/refund-order.js"), ...args], { encoding: "utf8" });
  assert.match(cli(at("../examples/order.json")).stdout, /^Refund +\$45\.95$/m);
  assert.deepEqual(JSON.parse(cli(at("../examples/order.json"), "--json").stdout), { items: 3700, fee: 0, shipping: 599, tax: 296, total: 4595 });
  assert.match(cli(at("../examples/order.json"), "--sku", "BEANS-1KG", "--opened", "BEANS-1KG").stdout, /^Restocking fee +-\$3\.60$/m);
  assert.deepEqual(JSON.parse(cli(at("../examples/order.json"), "--code", "SAVE10", "--sku", "FILTER-100", "--json").stdout), { items: 1170, fee: 0, shipping: 0, tax: 93, total: 1263 });
  assert.match(cli(at("../examples/order.json"), "--code", "SAVE10", "--sku", "FILTER-100").stdout, /^2 x Paper filters x100 +\$11\.70$/m);
  const unknown = cli(at("../examples/order.json"), "--sku", "TEA-50");
  assert.equal(unknown.status, 1);
  assert.match(unknown.stderr, /TEA-50/);
  assert.equal(cli().status, 1);
});
