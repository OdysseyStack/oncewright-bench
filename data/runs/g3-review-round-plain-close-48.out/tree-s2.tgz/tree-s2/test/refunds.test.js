import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { refundFor, renderRefundNote } from "../src/refunds.js";

const at = (p) => fileURLToPath(new URL(p, import.meta.url));
const order = {
  id: "A-1040",
  items: [
    { sku: "BEANS-1KG", name: "House beans 1kg", unitPrice: 2400, qty: 1 },
    { sku: "FILTER-100", name: "Paper filters x100", unitPrice: 650, qty: 2 },
  ],
};

test("a refund pays back the whole order", () => {
  assert.deepEqual(refundFor(order), { items: 3700, fee: 0, shipping: 599, tax: 296, total: 4595 });
  assert.deepEqual(refundFor(order, { code: "SAVE10" }), { items: 3330, fee: 0, shipping: 599, tax: 266, total: 4195 });
});

test("a refund of some lines pays back their amount and its tax, and no shipping", () => {
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"] }), { items: 1300, fee: 0, shipping: 0, tax: 104, total: 1404 });
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100", "BEANS-1KG"] }), refundFor(order));
});

test("a refund of some lines pays back the tax on their summed amount, as the order charged it", () => {
  const cents = {
    id: "A-1043",
    items: [
      { sku: "MUG-12OZ", name: "Mug 12oz", unitPrice: 619, qty: 1 },
      { sku: "SCOOP", name: "Coffee scoop", unitPrice: 1019, qty: 1 },
      { sku: "BEANS-1KG", name: "House beans 1kg", unitPrice: 2400, qty: 1 },
    ],
  };
  // 8% of 619 + 1019 = 1638 is 131.04: 131, where per line it would be 49 + 81 = 130.
  assert.deepEqual(refundFor(cents, { skus: ["MUG-12OZ", "SCOOP"] }), { items: 1638, fee: 0, shipping: 0, tax: 131, total: 1769 });
});

test("an opened line keeps a 15% restocking fee", () => {
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"] }), { items: 2400, fee: 360, shipping: 0, tax: 192, total: 2232 });
});

test("a SKU not on the order is an error", () => {
  assert.throws(() => refundFor(order, { skus: ["TEA-50"] }), /TEA-50/);
  assert.throws(() => refundFor(order, { skus: ["BEANS-1KG"], opened: ["TEA-50"] }), /TEA-50/);
});

test("a refund of some lines of a discounted order pays back their nets and the tax on them", () => {
  // SAVE10 takes 370 off: shares 240 and 130, so the filters' net is 1300 - 130 = 1170; 8% of it is 93.6.
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"], code: "SAVE10" }), { items: 1170, fee: 0, shipping: 0, tax: 93, total: 1263 });
  // TAKE5's 500 splits 324.32 / 175.68, so allocate gives the filters 176: net 1124, tax 89.92.
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"], code: "TAKE5" }), { items: 1124, fee: 0, shipping: 0, tax: 89, total: 1213 });
});

test("an opened line of a discounted order keeps 15% of its net", () => {
  // Net 2400 - 240 = 2160: the fee is 324, the tax 8% of 2160, 172.8.
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"], code: "SAVE10" }), { items: 2160, fee: 324, shipping: 0, tax: 172, total: 2008 });
});

test("a whole refund of a discounted order, by its SKUs or without, pays back what the order charged", () => {
  const whole = { items: 3330, fee: 0, shipping: 599, tax: 266, total: 4195 };
  assert.deepEqual(refundFor(order, { code: "SAVE10" }), whole);
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG", "FILTER-100"], code: "SAVE10" }), whole);
});

test("the refund note shows each part", () => {
  assert.equal(
    renderRefundNote(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"] }),
    "Refund for order A-1040\n\n1 x House beans 1kg  $24.00\n\nRestocking fee       -$3.60\nItems                $24.00\nShipping              $0.00\nTax                   $1.92\nRefund               $22.32",
  );
});

test("with a code, the refund note prints each line at its net price, and they add up to Items", () => {
  assert.equal(
    renderRefundNote(order, { skus: ["FILTER-100"], code: "TAKE5" }),
    "Refund for order A-1040\n\n2 x Paper filters x100  $11.24\n\nItems                   $11.24\nShipping                 $0.00\nTax                      $0.89\nRefund                  $12.13",
  );
  assert.match(renderRefundNote(order, { code: "SAVE10" }), /^1 x House beans 1kg +\$21\.60\n2 x Paper filters x100 +\$11\.70\n\nItems +\$33\.30$/m);
});

test("refund-order prints the note, or --json the amounts", () => {
  const cli = (...args) => spawnSync(process.execPath, [at("../bin/refund-order.js"), ...args], { encoding: "utf8" });
  assert.match(cli(at("../examples/order.json")).stdout, /^Refund +\$45\.95$/m);
  assert.deepEqual(JSON.parse(cli(at("../examples/order.json"), "--json").stdout), { items: 3700, fee: 0, shipping: 599, tax: 296, total: 4595 });
  assert.match(cli(at("../examples/order.json"), "--sku", "BEANS-1KG", "--opened", "BEANS-1KG").stdout, /^Restocking fee +-\$3\.60$/m);
  const unknown = cli(at("../examples/order.json"), "--sku", "TEA-50");
  assert.equal(unknown.status, 1);
  assert.match(unknown.stderr, /TEA-50/);
  assert.deepEqual(JSON.parse(cli(at("../examples/order.json"), "--code", "SAVE10", "--sku", "FILTER-100", "--json").stdout), { items: 1170, fee: 0, shipping: 0, tax: 93, total: 1263 });
  assert.match(cli(at("../examples/order.json"), "--code", "SAVE10", "--sku", "FILTER-100").stdout, /^2 x Paper filters x100 +\$11\.70$/m);
  assert.equal(cli().status, 1);
});
