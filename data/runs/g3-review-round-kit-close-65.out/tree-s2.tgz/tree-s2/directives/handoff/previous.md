# Handoff: refunds review fixes committed on `refunds-fixes`, not pushed

**Read first:** `export-check-ledger-check-missing`: `npm run check` skips the export import check on this machine (ledger-check isn't installed), so a green check means the tests passed and nothing more.

**State:** branch `refunds-fixes`, one commit 8be568c on top of main ("Refunds: tax a partial refund on the lines' summed amount"). Working tree clean. Not pushed, no PR open. Under the Odyssey rules, push or open a PR only when the user asks.

**First:** ask the user what to do with `refunds-fixes`: push it and open a PR, or merge it some other way. The commit dealt with CodeRabbit's findings in `review/findings-refunds.md`:
- Finding 1 (tax computed per line) fixed: `src/refunds.js:27` now does `percentOf(items, config.taxRate)`. Test in `test/refunds.test.js` with lines of $6.19 and $10.19 (tax 131, not 130).
- Finding 3 (use a `Set`) fixed in `linesFor`, `src/refunds.js:7-11`.
- Finding 2 (fold the restocking fee into `Items` on the note) declined, because the plan's Slice 2 point 5 (`docs/plans/2026-09-30-refunds.md:18-35`) asks for the separate negative `Restocking fee` line.

**Later:**
1. Refunds Slice 3, partial refunds of discounted orders: `docs/plans/2026-09-30-refunds.md:37-51`. Remove the throw at `src/refunds.js:23`, refund each line's `net` from `computeTotals(order, options).lines`, and take the fee on the `net`. Trap: point 1 says "the tax on it", which could be read as per line. Keep tax as `percentOf` of the summed nets, the same way finding 1 was fixed. Taking it per line brings back the cent-low bug.
2. Refunds Slice 4 is on hold. Don't change `percentOf` (`src/money.js`) or any amount it gives until finance amends the September filing.

**Open flags:**
- Finding 2 was declined because of the plan. If the user wants the note CodeRabbit describes, Slice 2 point 5 and Slice 3 point 2 have to change first.
- `review/findings-refunds.md` is still in the repo. Whether to delete or keep it is the user's call.
