# Handoff (written 2026-11-21, after CodeRabbit's refunds findings)

**Read first:** `export-check-ledger-check-missing`: on this machine `npm run check` runs only the tests. The export import check is skipped (ledger-check isn't installed), so don't report that check as passed.

**State:**
- Branch `refunds-fixes`, one commit `bec218d` on top of `main`. Not pushed, no PR, and nothing uncommitted apart from this file.
- The commit handles `review/findings-refunds.md`:
  - Finding 1 fixed: a partial refund's tax is now `percentOf` the refunded lines' total, in `src/refunds.js:26`. The new test is in `test/refunds.test.js:26-36`.
  - Finding 3 fixed: `linesFor` now uses a `Set`.
  - Finding 2 rejected: it would fold the restocking fee into `Items`, and the plan's Slice 2 point 5 asks for a separate negative fee line.
- Git rules: commit, push or open a PR only when the user asks. Never push to `main`.

**First:** ask the user whether to push `refunds-fixes` and open a PR, or merge it. Don't do either unprompted.

**Later:**
1. Refunds Slice 3, partial refunds of discounted orders: `docs/plans/2026-09-30-refunds.md:37-51`.
   - It changes `src/refunds.js` (the throw at line 23, `items`, `fee`, `tax` at lines 24-27, and the note's line rows at line 35) and `test/refunds.test.js`. It also touches `bin/refund-order.js` and the README.
   - Trap: take the tax on the sum of the refunded lines' nets. Per line was finding 1's bug.
   - Trap: don't touch `percentOf`'s floor in `src/money.js`. Slice 4 waits on finance's amended tax filing.
   - Mark Slice 3 done in the plan's status line when it's finished.

**Open flags:**
- Finding 2 (show the fee already taken off `Items` and drop the `Restocking fee` row) was rejected because of the plan. If the user wants that layout, the plan's Slice 2 point 5 and Slice 3 point 2 must change first. Ask them.
