import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { refundFor, renderRefundNote } from "../src/refunds.js";

const at = (p) => fileURLToPath(new URL(p, import.meta.url));
const order = {
  id: "A-1040",
  items: [
    { sku: "BEANS-1KG", name: "House beans 1kg", unitPrice: 2400, qty: 1 },
    { sku: "FILTER-100", name: "Paper filters x100", unitPrice: 650, qty: 2 },
  ],
};

test("a refund pays back the whole order", () => {
  assert.deepEqual(refundFor(order), { items: 3700, fee: 0, shipping: 599, tax: 296, total: 4595 });
  assert.deepEqual(refundFor(order, { code: "SAVE10" }), { items: 3330, fee: 0, shipping: 599, tax: 266, total: 4195 });
});

test("a refund of some lines pays back their amount and its tax, and no shipping", () => {
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"] }), { items: 1300, fee: 0, shipping: 0, tax: 104, total: 1404 });
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100", "BEANS-1KG"] }), refundFor(order));
});

const small = {
  items: [
    { sku: "A", name: "A", unitPrice: 619, qty: 1 },
    { sku: "B", name: "B", unitPrice: 1019, qty: 1 },
    { sku: "C", name: "C", unitPrice: 500, qty: 1 },
  ],
};

test("the tax on some lines is charged on their summed amount, not line by line", () => {
  // 8% of 1638 is 131.04, so 131; line by line it would be 49 + 81 = 130.
  assert.equal(refundFor(small, { skus: ["A", "B"] }).tax, 131);
});

test("a refund of some lines of a discounted order pays back their nets and the tax on them", () => {
  // SAVE10 takes 370 off: BEANS-1KG's share is 240 (net 2160), FILTER-100's 130 (net 1170).
  // 8% of 1170 is 93.6, so 93.
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"], code: "SAVE10" }), { items: 1170, fee: 0, shipping: 0, tax: 93, total: 1263 });
  // TAKE5 takes 500 off: FILTER-100's share is 176 (net 1124). 8% of 1124 is 89.92, so 89.
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"], code: "TAKE5" }), { items: 1124, fee: 0, shipping: 0, tax: 89, total: 1213 });
});

test("the tax on some discounted lines is charged on their summed nets, not line by line", () => {
  // SAVE10 nets: A 557, B 918. 8% of 1475 is 118; line by line it would be 44 + 73 = 117.
  assert.equal(refundFor(small, { skus: ["A", "B"], code: "SAVE10" }).tax, 118);
});

test("an opened line of a discounted order keeps 15% of its net", () => {
  // 15% of BEANS-1KG's net 2160 is 324; 8% of 2160 is 172.8, so 172.
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"], code: "SAVE10" }), { items: 2160, fee: 324, shipping: 0, tax: 172, total: 2008 });
  // 15% of FILTER-100's net 1170 is 175.5, so 175.
  assert.equal(refundFor(order, { code: "SAVE10", opened: ["FILTER-100"] }).fee, 175);
});

test("a whole refund of a discounted order, line by line, gives the same amounts as Slice 1", () => {
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG", "FILTER-100"], code: "SAVE10" }), refundFor(order, { code: "SAVE10" }));
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG", "FILTER-100"], code: "TAKE5" }), refundFor(order, { code: "TAKE5" }));
});

test("an opened line keeps a 15% restocking fee", () => {
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"] }), { items: 2400, fee: 360, shipping: 0, tax: 192, total: 2232 });
});

test("a SKU not on the order is an error", () => {
  assert.throws(() => refundFor(order, { skus: ["TEA-50"] }), /TEA-50/);
  assert.throws(() => refundFor(order, { skus: ["BEANS-1KG"], code: "SAVE10", opened: ["TEA-50"] }), /TEA-50/);
});

test("the refund note shows each part", () => {
  assert.equal(
    renderRefundNote(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"] }),
    "Refund for order A-1040\n\n1 x House beans 1kg  $24.00\n\nRestocking fee       -$3.60\nItems                $24.00\nShipping              $0.00\nTax                   $1.92\nRefund               $22.32",
  );
});

test("the refund note of a discounted order prints each line at its net, and Items is their sum", () => {
  assert.equal(
    renderRefundNote(order, { skus: ["FILTER-100"], code: "SAVE10" }),
    "Refund for order A-1040\n\n2 x Paper filters x100  $11.70\n\nItems                   $11.70\nShipping                 $0.00\nTax                      $0.93\nRefund                  $12.63",
  );
  assert.equal(
    renderRefundNote(order, { code: "SAVE10" }),
    "Refund for order A-1040\n\n1 x House beans 1kg     $21.60\n2 x Paper filters x100  $11.70\n\nItems                   $33.30\nShipping                 $5.99\nTax                      $2.66\nRefund                  $41.95",
  );
});

test("refund-order prints the note, or --json the amounts", () => {
  const cli = (...args) => spawnSync(process.execPath, [at("../bin/refund-order.js"), ...args], { encoding: "utf8" });
  assert.match(cli(at("../examples/order.json")).stdout, /^Refund +\$45\.95$/m);
  assert.deepEqual(JSON.parse(cli(at("../examples/order.json"), "--json").stdout), { items: 3700, fee: 0, shipping: 599, tax: 296, total: 4595 });
  assert.match(cli(at("../examples/order.json"), "--sku", "BEANS-1KG", "--opened", "BEANS-1KG").stdout, /^Restocking fee +-\$3\.60$/m);
  const discounted = cli(at("../examples/order.json"), "--code", "SAVE10", "--sku", "FILTER-100", "--json");
  assert.equal(discounted.status, 0);
  assert.deepEqual(JSON.parse(discounted.stdout), { items: 1170, fee: 0, shipping: 0, tax: 93, total: 1263 });
  assert.match(cli(at("../examples/order.json"), "--code", "SAVE10", "--sku", "FILTER-100").stdout, /^2 x Paper filters x100 +\$11\.70$/m);
  const unknown = cli(at("../examples/order.json"), "--sku", "TEA-50");
  assert.equal(unknown.status, 1);
  assert.match(unknown.stderr, /TEA-50/);
  assert.equal(cli().status, 1);
});
