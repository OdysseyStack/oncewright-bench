CodeRabbit's refunds findings are dealt with on branch `refunds-fixes` (commit 2cb783a); nothing pushed, no PR.

**Read first:** `ledger-check-not-installed`: `npm run check` doesn't run the export import check on this machine, so tell the user it was skipped.

**State:** on `refunds-fixes`, working tree clean. The branch isn't pushed and has no PR. Push, open a PR or merge only if the user asks. The fix changed only `src/refunds.js` and `test/refunds.test.js`.

**First:** ask the user about the open flag below. Then, if they want it, start refunds Slice 3 (`docs/plans/2026-09-30-refunds.md`, section "Slice 3"). It changes `src/refunds.js` (refundFor, lines 16-30; renderRefundNote, from line 33), `bin/refund-order.js`, the README and `test/refunds.test.js`.
- Trap: Slice 3 point 1 says "the tax on it", which reads as tax per line. Slice 2 point 1, and this session's fix at `src/refunds.js:26-27`, tax the *summed* refunded amount once. Line-by-line flooring loses a cent (test "the tax on some lines is charged on their summed amount"). Keep summing, and ask the user before doing otherwise.
- Trap: leave `percentOf` in `src/money.js` flooring until Slice 4. Finance has to amend a tax filing in the same release as that fix.

**Later:** refunds Slice 3, then whatever the user picks from the other plans in `docs/plans/`.

**Open flags:**
- I turned down CodeRabbit's finding 2: fold the restocking fee into `Items` on the refund note and drop the `Restocking fee` line. Plan Slice 2 point 5 asks for a separate negative fee line. The user hasn't confirmed this. If they want CodeRabbit's layout, update the plan first, then the note and its tests.
