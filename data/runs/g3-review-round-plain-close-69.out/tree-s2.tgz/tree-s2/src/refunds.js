// Refunds: a whole order (the refund plan's Slice 1), or some of its lines (Slices 2 and 3).
import { config } from "./config.js";
import { formatMoney, percentOf, sumCents } from "./money.js";
import { computeTotals } from "./totals.js";

// The order's lines a refund covers: those whose SKUs are listed, or all of them. Each carries its
// net: its amount less its share of any discount, from computeTotals.
const linesFor = (order, options) => {
  const { lines } = computeTotals(order, options);
  const withNet = order.items.map((item, i) => ({ ...item, net: lines[i].net }));
  if (options.skus === undefined) return withNet;
  const wanted = new Set(options.skus);
  return withNet.filter((item) => wanted.has(item.sku));
};

// What a refund pays back, in cents: { items, fee, shipping, tax, total }. options: the options the
// order was priced with (pickup, code), plus skus, the lines to refund (all of them when absent),
// and opened, the refunded lines that keep a restocking fee.
export function refundFor(order, options = {}) {
  const t = computeTotals(order, options);
  const { skus, opened = [] } = options;
  const unknown = [...(skus ?? []), ...opened].find((sku) => !order.items.some((item) => item.sku === sku));
  if (unknown !== undefined) throw new Error(`SKU not on the order: ${unknown}`);
  const lines = linesFor(order, options);
  const whole = lines.length === order.items.length;
  const fee = sumCents(lines.filter((item) => opened.includes(item.sku)).map((item) => percentOf(item.net, config.restockingFee)));
  // The nets add up to the subtotal less the discount (allocate makes the shares add up to it), so
  // a whole refund pays back what the order charged for its items.
  const items = sumCents(lines.map((item) => item.net));
  // Tax on the lines' summed amount, as computeTotals charges it: per line, percentOf would drop
  // a fraction of a cent on each and refund less tax than the order charged.
  const tax = whole ? t.tax : percentOf(items, config.taxRate);
  const shipping = whole ? t.shipping : 0;
  return { items, fee, shipping, tax, total: items - fee + shipping + tax };
}

// The note the customer gets with a refund: the refunded lines, each at its net price as on the
// receipt, then the totals.
export function renderRefundNote(order, options = {}) {
  const r = refundFor(order, options);
  const rows = [
    ...linesFor(order, options).map((item) => [`${item.qty} x ${item.name}`, item.net]),
    null,
    ...(r.fee ? [["Restocking fee", -r.fee]] : []),
    ["Items", r.items],
    ["Shipping", r.shipping],
    ["Tax", r.tax],
    ["Refund", r.total],
  ].map((row) => row && [row[0], formatMoney(row[1])]);
  const width = Math.max(...rows.filter(Boolean).map(([label, amount]) => label.length + amount.length)) + 2;
  return [
    `Refund for order ${order.id ?? "(no id)"}`,
    "",
    ...rows.map((row) => (row ? row[0] + row[1].padStart(width - row[0].length) : "")),
  ].join("\n");
}
