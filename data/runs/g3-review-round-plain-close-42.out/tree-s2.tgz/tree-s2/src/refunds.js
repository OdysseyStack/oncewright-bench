// Refunds: a whole order (the refund plan's Slice 1), some of its lines (Slice 2), and some lines
// of a discounted order (Slice 3).
import { config } from "./config.js";
import { formatMoney, percentOf, sumCents } from "./money.js";
import { computeTotals } from "./totals.js";

// The order's lines a refund covers, those whose SKUs are listed (all of them when skus is absent),
// each as { item, net }: net is the line's amount less its share of any discount (computeTotals).
const linesFor = (order, totals, skus) => {
  const wanted = skus === undefined ? null : new Set(skus);
  return order.items
    .map((item, i) => ({ item, net: totals.lines[i].net }))
    .filter(({ item }) => wanted === null || wanted.has(item.sku));
};

// What a refund pays back, in cents: { items, fee, shipping, tax, total }. options: the options the
// order was priced with (pickup, code), plus skus, the lines to refund (all of them when absent),
// and opened, the refunded lines that keep a restocking fee. Each line pays back its net, so a
// discounted order's lines pay back their price after their share of the discount.
export function refundFor(order, options = {}) {
  const t = computeTotals(order, options);
  const { skus, opened = [] } = options;
  const unknown = [...(skus ?? []), ...opened].find((sku) => !order.items.some((item) => item.sku === sku));
  if (unknown !== undefined) throw new Error(`SKU not on the order: ${unknown}`);
  const lines = linesFor(order, t, skus);
  const whole = lines.length === order.items.length;
  const fee = sumCents(lines.filter(({ item }) => opened.includes(item.sku)).map(({ net }) => percentOf(net, config.restockingFee)));
  // The nets of all the lines add up to subtotal - discount, so a whole refund matches the order.
  const items = sumCents(lines.map(({ net }) => net));
  // Tax on the lines' summed amount, as computeTotals charges it, not summed per line.
  const tax = whole ? t.tax : percentOf(items, config.taxRate);
  const shipping = whole ? t.shipping : 0;
  return { items, fee, shipping, tax, total: items - fee + shipping + tax };
}

// The note the customer gets with a refund: the refunded lines, each at its net price as on the
// receipt, then the totals.
export function renderRefundNote(order, options = {}) {
  const r = refundFor(order, options);
  const rows = [
    ...linesFor(order, computeTotals(order, options), options.skus).map(({ item, net }) => [`${item.qty} x ${item.name}`, net]),
    null,
    ...(r.fee ? [["Restocking fee", -r.fee]] : []),
    ["Items", r.items],
    ["Shipping", r.shipping],
    ["Tax", r.tax],
    ["Refund", r.total],
  ].map((row) => row && [row[0], formatMoney(row[1])]);
  const width = Math.max(...rows.filter(Boolean).map(([label, amount]) => label.length + amount.length)) + 2;
  return [
    `Refund for order ${order.id ?? "(no id)"}`,
    "",
    ...rows.map((row) => (row ? row[0] + row[1].padStart(width - row[0].length) : "")),
  ].join("\n");
}
