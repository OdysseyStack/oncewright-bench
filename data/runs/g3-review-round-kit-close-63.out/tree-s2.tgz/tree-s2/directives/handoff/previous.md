# Handoff: refunds-fixes committed (eeb74e4); refunds Slice 3 is next

**Read first:** `export-check-skips-without-ledger-check`: a green `npm run check` here never ran the export import check.

**State:** branch `refunds-fixes`, one commit `eeb74e4` on top of `main` ("Refund tax on the refunded lines' summed amount"). Not pushed, no PR. Nothing else uncommitted except this file.
CodeRabbit's three findings (`review/findings-refunds.md`) are dealt with:
- #1 accepted: partial-refund tax is now `percentOf(items, taxRate)` on the summed amount (`src/refunds.js` ~line 26), with a test for $6.19 + $10.19 → $1.31.
- #3 accepted: `linesFor` uses a Set.
- #2 rejected: it goes against refunds plan Slice 2 point 5, which keeps the separate negative `Restocking fee` row.

**First:** refunds plan Slice 3, partial refunds of discounted orders (`docs/plans/2026-09-30-refunds.md`, "Slice 3").
- Reads: `src/totals.js:22-34` (`computeTotals`, its `lines` with `net`).
- Changes:
  - `src/refunds.js:12-30`: drop the discount-code throw; refund each line's `net`, tax on the summed nets, and a fee of 15% of `net`.
  - `src/refunds.js` `renderRefundNote`: print lines at their net price.
  - `bin/refund-order.js`: `--code` works with `--sku`.
  - README: drop the "not supported yet" note.
  - `test/refunds.test.js:30-33`: the discount-throw assertion goes.
- Keep `percentOf` as it is: Slice 4 holds the rounding fix.
- Mark Slice 3 done in the plan's status line.
- Start with `/odyssey:prove-it` (test first).

**Later:** refunds Slice 4 (round tax to the nearest cent) waits on Finance's amended September filing, so don't start it unasked.

**Open flags:**
- Should `refunds-fixes` be pushed / opened as a PR? Should Slice 3 branch from it or from `main`? (Slice 3 builds on the tax fix, so branching from it is the likely pick.) Ask.
- Finding #2 was rejected under the plan. If the user wants the note to show Items after the fee, the plan's Slice 2 point 5 has to change first. That's their decision.
- No CHANGELOG line for the tax fix (the export format didn't change, so the repo doesn't require one). Ask if they want one.
