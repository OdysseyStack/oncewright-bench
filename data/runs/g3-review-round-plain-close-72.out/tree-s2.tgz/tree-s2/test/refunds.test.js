import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { refundFor, renderRefundNote } from "../src/refunds.js";
import { computeTotals } from "../src/totals.js";

const at = (p) => fileURLToPath(new URL(p, import.meta.url));
const order = {
  id: "A-1040",
  items: [
    { sku: "BEANS-1KG", name: "House beans 1kg", unitPrice: 2400, qty: 1 },
    { sku: "FILTER-100", name: "Paper filters x100", unitPrice: 650, qty: 2 },
  ],
};

test("a refund pays back the whole order", () => {
  assert.deepEqual(refundFor(order), { items: 3700, fee: 0, shipping: 599, tax: 296, total: 4595 });
  assert.deepEqual(refundFor(order, { code: "SAVE10" }), { items: 3330, fee: 0, shipping: 599, tax: 266, total: 4195 });
});

test("a refund of some lines pays back their amount and its tax, and no shipping", () => {
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"] }), { items: 1300, fee: 0, shipping: 0, tax: 104, total: 1404 });
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100", "BEANS-1KG"] }), refundFor(order));
});

test("the tax on some lines is charged on their summed amount, not line by line", () => {
  const odd = {
    items: [
      { sku: "A", name: "A", unitPrice: 619, qty: 1 },
      { sku: "B", name: "B", unitPrice: 1019, qty: 1 },
      { sku: "C", name: "C", unitPrice: 500, qty: 1 },
    ],
  };
  // Line by line: 49 + 81 = 130. On the sum: 1638 at 8% = 131.
  assert.equal(refundFor(odd, { skus: ["A", "B"] }).tax, 131);
  assert.equal(refundFor(odd, { skus: ["A", "B"] }).tax, computeTotals({ items: odd.items.slice(0, 2) }).tax);
});

test("an opened line keeps a 15% restocking fee", () => {
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"] }), { items: 2400, fee: 360, shipping: 0, tax: 192, total: 2232 });
});

test("a SKU not on the order is an error", () => {
  assert.throws(() => refundFor(order, { skus: ["TEA-50"] }), /TEA-50/);
  assert.throws(() => refundFor(order, { skus: ["BEANS-1KG"], opened: ["TEA-50"] }), /TEA-50/);
});

test("a refund of some lines of a discounted order pays back each line's net and the tax on it", () => {
  // SAVE10 takes 370 off: 240 from the beans, 130 from the filters.
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], code: "SAVE10" }), { items: 2160, fee: 0, shipping: 0, tax: 172, total: 2332 });
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"], code: "SAVE10" }), { items: 1170, fee: 0, shipping: 0, tax: 93, total: 1263 });
  // TAKE5 takes 500 off, which doesn't split evenly: allocate gives the filters 176, so their net is 1124.
  const { lines } = computeTotals(order, { code: "TAKE5" });
  assert.equal(lines[1].net, 1124);
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"], code: "TAKE5" }), { items: 1124, fee: 0, shipping: 0, tax: 89, total: 1213 });
});

test("an opened line of a discounted order keeps 15% of its net", () => {
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"], code: "SAVE10" }), { items: 2160, fee: 324, shipping: 0, tax: 172, total: 2008 });
  assert.equal(refundFor(order, { opened: ["BEANS-1KG"], code: "SAVE10" }).fee, 324);
});

test("refunding every line of a discounted order gives the whole-order refund", () => {
  for (const code of ["SAVE10", "STAFF25", "TAKE5"]) {
    assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG", "FILTER-100"], code }), refundFor(order, { code }));
  }
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100", "BEANS-1KG"], code: "SAVE10" }), { items: 3330, fee: 0, shipping: 599, tax: 266, total: 4195 });
});

test("the refund note's lines add up to Items, and the parts to Refund, for the bookkeeper's import", () => {
  const money = (text) => Number(text.replace(/[$.]/g, ""));
  for (const code of [undefined, "SAVE10", "STAFF25", "TAKE5"]) {
    for (const skus of [undefined, ["BEANS-1KG"], ["FILTER-100"]]) {
      const options = { code, skus, opened: ["BEANS-1KG"].filter((sku) => !skus || skus.includes(sku)) };
      const note = renderRefundNote(order, options);
      const r = refundFor(order, options);
      const lines = note.split("\n").filter((line) => / x /.test(line)).map((line) => money(line.trim().split(/ +/).pop()));
      assert.equal(lines.reduce((a, b) => a + b, 0), r.items, note);
      assert.match(note, new RegExp(`^Items +\\$${(r.items / 100).toFixed(2).replace(".", "\\.")}$`, "m"));
      assert.equal(r.items - r.fee + r.shipping + r.tax, r.total);
    }
  }
});

test("the refund note shows each part", () => {
  assert.equal(
    renderRefundNote(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"] }),
    "Refund for order A-1040\n\n1 x House beans 1kg  $24.00\n\nRestocking fee       -$3.60\nItems                $24.00\nShipping              $0.00\nTax                   $1.92\nRefund               $22.32",
  );
});

test("the refund note prints a discounted order's lines at their net price", () => {
  assert.equal(
    renderRefundNote(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"], code: "SAVE10" }),
    "Refund for order A-1040\n\n1 x House beans 1kg  $21.60\n\nRestocking fee       -$3.24\nItems                $21.60\nShipping              $0.00\nTax                   $1.72\nRefund               $20.08",
  );
});

test("refund-order prints the note, or --json the amounts", () => {
  const cli = (...args) => spawnSync(process.execPath, [at("../bin/refund-order.js"), ...args], { encoding: "utf8" });
  assert.match(cli(at("../examples/order.json")).stdout, /^Refund +\$45\.95$/m);
  assert.deepEqual(JSON.parse(cli(at("../examples/order.json"), "--json").stdout), { items: 3700, fee: 0, shipping: 599, tax: 296, total: 4595 });
  assert.match(cli(at("../examples/order.json"), "--sku", "BEANS-1KG", "--opened", "BEANS-1KG").stdout, /^Restocking fee +-\$3\.60$/m);
  const unknown = cli(at("../examples/order.json"), "--sku", "TEA-50");
  assert.equal(unknown.status, 1);
  assert.match(unknown.stderr, /TEA-50/);
  assert.deepEqual(JSON.parse(cli(at("../examples/order.json"), "--code", "SAVE10", "--sku", "BEANS-1KG", "--json").stdout), { items: 2160, fee: 0, shipping: 0, tax: 172, total: 2332 });
  assert.match(cli(at("../examples/order.json"), "--code", "SAVE10", "--sku", "BEANS-1KG").stdout, /^1 x House beans 1kg +\$21\.60$/m);
  assert.equal(cli().status, 1);
});
