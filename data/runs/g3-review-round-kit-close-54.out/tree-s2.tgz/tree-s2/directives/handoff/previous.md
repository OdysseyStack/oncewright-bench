# Handoff from 2026-11-19 (CodeRabbit refunds findings)

**Read first:** `ledger-check-missing`: a green `npm run check` here skips the export import check.

**State:** branch `refunds-fixes`, clean, one commit `4304be6` on top of `main`, not pushed and
no PR. Push or open a PR only when the user asks.

**First:** ask the user whether to push `refunds-fixes` and open a PR. The commit does two things:
the partial-refund tax is now `percentOf` the summed amount (`src/refunds.js:26`), and `linesFor`
uses a Set. There's a new test in `test/refunds.test.js` (lines of $6.19 + $10.19 refund $1.31 tax).

**Later:** refunds plan Slice 3 (partial refunds of discounted orders),
`docs/plans/2026-09-30-refunds.md`. It touches `src/refunds.js` and `test/refunds.test.js`,
`bin/refund-order.js` and the README.

**Open flags:**
- CodeRabbit's note finding in `review/findings-refunds.md` (fold the restocking fee into `Items`,
  drop the `Restocking fee` row) was rejected because it contradicts the plan's Slice 2 point 5.
  The user hasn't said yes or no. If they want it, the plan changes first.
- Slice 4 of the plan (round tax to the nearest cent) still waits on finance. Leave `percentOf` alone.
