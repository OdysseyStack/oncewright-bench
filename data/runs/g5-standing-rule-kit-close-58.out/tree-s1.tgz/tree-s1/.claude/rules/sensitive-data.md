# Sensitive data

What this project treats as sensitive, by category and field name, never by value. Logs carry
structural fields only (event names, opaque correlation ids, lengths, counts, statuses,
durations), never these.

## End-user identifiers

- customer

## Free-text content

- None named.

## External request/response payloads

- None named.

## Credentials

Where they live, as file names and variable names, never a value:

- .env

A value that reaches the transcript must be rotated, so never print one:

- Don't `cat`, `sed` or `grep` a file that holds one; count a name: `grep -c '^NAME=' <file>`.
- Test a variable with `[ -n "$NAME" ] && echo set`; `${NAME:-UNSET}` prints it.
- Report a secret's length and whether it parses, never any part of it (a prefix included),
  nor of a response that echoes one.
