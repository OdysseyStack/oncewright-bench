import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { refundFor, renderRefundNote } from "../src/refunds.js";
import { computeTotals } from "../src/totals.js";

const at = (p) => fileURLToPath(new URL(p, import.meta.url));
const order = {
  id: "A-1040",
  items: [
    { sku: "BEANS-1KG", name: "House beans 1kg", unitPrice: 2400, qty: 1 },
    { sku: "FILTER-100", name: "Paper filters x100", unitPrice: 650, qty: 2 },
  ],
};

test("a refund pays back the whole order", () => {
  assert.deepEqual(refundFor(order), { items: 3700, fee: 0, shipping: 599, tax: 296, total: 4595 });
  assert.deepEqual(refundFor(order, { code: "SAVE10" }), { items: 3330, fee: 0, shipping: 599, tax: 266, total: 4195 });
});

test("a refund of some lines pays back their amount and its tax, and no shipping", () => {
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"] }), { items: 1300, fee: 0, shipping: 0, tax: 104, total: 1404 });
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100", "BEANS-1KG"] }), refundFor(order));
});

test("a refund of some lines pays the tax on their summed amount, as the order charged it", () => {
  const odd = {
    items: [
      { sku: "A", name: "A", unitPrice: 619, qty: 1 },
      { sku: "B", name: "B", unitPrice: 1019, qty: 1 },
      { sku: "C", name: "C", unitPrice: 500, qty: 1 },
    ],
  };
  // 8% of $6.19 and of $10.19 is $0.49 and $0.81 dropping fractions, but of $16.38 it is $1.31.
  assert.deepEqual(refundFor(odd, { skus: ["A", "B"] }), { items: 1638, fee: 0, shipping: 0, tax: 131, total: 1769 });
});

test("an opened line keeps a 15% restocking fee", () => {
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"] }), { items: 2400, fee: 360, shipping: 0, tax: 192, total: 2232 });
});

test("a SKU not on the order is an error", () => {
  assert.throws(() => refundFor(order, { skus: ["TEA-50"] }), /TEA-50/);
  assert.throws(() => refundFor(order, { skus: ["BEANS-1KG"], opened: ["TEA-50"] }), /TEA-50/);
});

test("a refund of some lines of a discounted order pays back their nets and the tax on them", () => {
  // SAVE10 takes $2.40 off the beans and $1.30 off the filters.
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], code: "SAVE10" }), { items: 2160, fee: 0, shipping: 0, tax: 172, total: 2332 });
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"], code: "SAVE10" }), { items: 1170, fee: 0, shipping: 0, tax: 93, total: 1263 });
  // TAKE5's $5.00 shared in proportion: $3.24 off the beans, $1.76 off the filters.
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"], code: "take5" }), { items: 1124, fee: 0, shipping: 0, tax: 89, total: 1213 });
});

test("an opened line of a discounted order keeps 15% of its net", () => {
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"], code: "SAVE10" }), { items: 2160, fee: 324, shipping: 0, tax: 172, total: 2008 });
});

test("refunding every line of a discounted order gives the whole refund", () => {
  const whole = { items: 3330, fee: 0, shipping: 599, tax: 266, total: 4195 };
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG", "FILTER-100"], code: "SAVE10" }), whole);
  assert.deepEqual(refundFor(order, { code: "SAVE10" }), whole);
  for (const code of ["STAFF25", "TAKE5"]) {
    const { subtotal, discount, shipping, tax, total } = computeTotals(order, { code });
    assert.deepEqual(refundFor(order, { skus: ["FILTER-100", "BEANS-1KG"], code }), { items: subtotal - discount, fee: 0, shipping, tax, total });
  }
});

test("the refund note shows each part", () => {
  assert.equal(
    renderRefundNote(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"] }),
    "Refund for order A-1040\n\n1 x House beans 1kg  $24.00\n\nRestocking fee       -$3.60\nItems                $24.00\nShipping              $0.00\nTax                   $1.92\nRefund               $22.32",
  );
});

test("the refund note of a discounted order prints each line at its net, adding up to Items", () => {
  assert.equal(
    renderRefundNote(order, { skus: ["FILTER-100"], code: "TAKE5", opened: ["FILTER-100"] }),
    "Refund for order A-1040\n\n2 x Paper filters x100  $11.24\n\nRestocking fee          -$1.68\nItems                   $11.24\nShipping                 $0.00\nTax                      $0.89\nRefund                  $10.45",
  );
  assert.equal(
    renderRefundNote(order, { code: "SAVE10" }),
    "Refund for order A-1040\n\n1 x House beans 1kg     $21.60\n2 x Paper filters x100  $11.70\n\nItems                   $33.30\nShipping                 $5.99\nTax                      $2.66\nRefund                  $41.95",
  );
});

test("refund-order prints the note, or --json the amounts", () => {
  const cli = (...args) => spawnSync(process.execPath, [at("../bin/refund-order.js"), ...args], { encoding: "utf8" });
  assert.match(cli(at("../examples/order.json")).stdout, /^Refund +\$45\.95$/m);
  assert.deepEqual(JSON.parse(cli(at("../examples/order.json"), "--json").stdout), { items: 3700, fee: 0, shipping: 599, tax: 296, total: 4595 });
  assert.match(cli(at("../examples/order.json"), "--sku", "BEANS-1KG", "--opened", "BEANS-1KG").stdout, /^Restocking fee +-\$3\.60$/m);
  assert.deepEqual(JSON.parse(cli(at("../examples/order.json"), "--code", "SAVE10", "--sku", "BEANS-1KG", "--json").stdout), { items: 2160, fee: 0, shipping: 0, tax: 172, total: 2332 });
  assert.match(cli(at("../examples/order.json"), "--code", "SAVE10", "--sku", "BEANS-1KG").stdout, /^1 x House beans 1kg +\$21\.60$/m);
  const unknown = cli(at("../examples/order.json"), "--sku", "TEA-50");
  assert.equal(unknown.status, 1);
  assert.match(unknown.stderr, /TEA-50/);
  assert.equal(cli().status, 1);
});
