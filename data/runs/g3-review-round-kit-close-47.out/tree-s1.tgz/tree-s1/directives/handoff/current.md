# Handoff from 2026-11-19 (CodeRabbit refunds findings)

**Read first:** `ledger-check-missing` (a green `npm run check` here covers the tests only).

**State:** branch `refunds-fixes`, one commit `7019321` on top of `main`, not pushed, no PR. Tree clean.
Findings were in `review/findings-refunds.md`:
- #1 (partial refund tax per line) fixed: `src/refunds.js:26-27` taxes the summed amount; test in
  `test/refunds.test.js` (lines $6.19 + $10.19 → $1.31) fails on the old code.
- #3 (Set in `linesFor`) applied, `src/refunds.js:7-11`.
- #2 rejected: it contradicts `docs/plans/2026-09-30-refunds.md` Slice 2 point 5 (negative
  `Restocking fee` row) and README line 56 (printed lines add up to `Items`).

**First:** ask the user whether to push `refunds-fixes` and open a PR (not asked yet). After a push to a PR
that CodeRabbit reviews, dispatch `cr-triage` in the background (global CLAUDE.md rule).

**Later:** refunds plan Slice 3 (partial refunds of discounted orders) is next in the plan. Slice 4
(rounding in `percentOf`) is on hold: leave `percentOf` as it is until finance is ready.

**Open flags:**
- Finding #2: if the user wants the refund note to show `Items` after the fee, the plan's Slice 2 point 5
  and README line 56 change first. Not decided.
