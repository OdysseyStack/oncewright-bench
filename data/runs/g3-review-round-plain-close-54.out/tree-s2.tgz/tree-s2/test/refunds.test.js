import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { refundFor, renderRefundNote } from "../src/refunds.js";
import { computeTotals } from "../src/totals.js";

const at = (p) => fileURLToPath(new URL(p, import.meta.url));
const order = {
  id: "A-1040",
  items: [
    { sku: "BEANS-1KG", name: "House beans 1kg", unitPrice: 2400, qty: 1 },
    { sku: "FILTER-100", name: "Paper filters x100", unitPrice: 650, qty: 2 },
  ],
};

test("a refund pays back the whole order", () => {
  assert.deepEqual(refundFor(order), { items: 3700, fee: 0, shipping: 599, tax: 296, total: 4595 });
  assert.deepEqual(refundFor(order, { code: "SAVE10" }), { items: 3330, fee: 0, shipping: 599, tax: 266, total: 4195 });
});

test("a refund of some lines pays back their amount and its tax, and no shipping", () => {
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"] }), { items: 1300, fee: 0, shipping: 0, tax: 104, total: 1404 });
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100", "BEANS-1KG"] }), refundFor(order));
});

test("the tax on some lines is charged on their summed amount, not line by line", () => {
  const mixed = {
    id: "A-1050",
    items: [
      { sku: "MUG-12OZ", name: "Mug 12oz", unitPrice: 619, qty: 1 },
      { sku: "DRIPPER", name: "Dripper", unitPrice: 1019, qty: 1 },
      { sku: "BEANS-1KG", name: "House beans 1kg", unitPrice: 2400, qty: 1 },
    ],
  };
  // Per line, 49.52 + 81.52 cents would floor to 49 + 81 = 130; on the sum, 131.04 floors to 131.
  assert.deepEqual(refundFor(mixed, { skus: ["MUG-12OZ", "DRIPPER"] }), { items: 1638, fee: 0, shipping: 0, tax: 131, total: 1769 });
});

test("an opened line keeps a 15% restocking fee", () => {
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"] }), { items: 2400, fee: 360, shipping: 0, tax: 192, total: 2232 });
});

test("a SKU not on the order is an error", () => {
  assert.throws(() => refundFor(order, { skus: ["TEA-50"] }), /TEA-50/);
  assert.throws(() => refundFor(order, { skus: ["BEANS-1KG"], opened: ["TEA-50"], code: "SAVE10" }), /TEA-50/);
});

test("a refund of some lines of a discounted order pays back their net amounts and the tax on them", () => {
  // SAVE10 takes 240 off the beans and 130 off the filters.
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], code: "SAVE10" }), { items: 2160, fee: 0, shipping: 0, tax: 172, total: 2332 });
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"], code: "SAVE10" }), { items: 1170, fee: 0, shipping: 0, tax: 93, total: 1263 });
  // TAKE5's 500 is shared 324 / 176 in proportion to the lines' amounts.
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], code: "TAKE5" }), { items: 2076, fee: 0, shipping: 0, tax: 166, total: 2242 });
});

test("an opened line of a discounted order keeps 15% of its net amount", () => {
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"], code: "SAVE10" }), { items: 2160, fee: 324, shipping: 0, tax: 172, total: 2008 });
});

test("a whole refund of a discounted order pays back what the order charged, listing every line or none", () => {
  for (const code of ["SAVE10", "STAFF25", "TAKE5"]) {
    const t = computeTotals(order, { code });
    const whole = { items: t.subtotal - t.discount, fee: 0, shipping: t.shipping, tax: t.tax, total: t.total };
    assert.deepEqual(refundFor(order, { code }), whole);
    assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG", "FILTER-100"], code }), whole);
  }
});

test("the refund note shows each part", () => {
  assert.equal(
    renderRefundNote(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"] }),
    "Refund for order A-1040\n\n1 x House beans 1kg  $24.00\n\nRestocking fee       -$3.60\nItems                $24.00\nShipping              $0.00\nTax                   $1.92\nRefund               $22.32",
  );
});

test("with a code, the note prints each line at its net amount, and they add up to Items", () => {
  assert.equal(
    renderRefundNote(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"], code: "SAVE10" }),
    "Refund for order A-1040\n\n1 x House beans 1kg  $21.60\n\nRestocking fee       -$3.24\nItems                $21.60\nShipping              $0.00\nTax                   $1.72\nRefund               $20.08",
  );
  assert.equal(
    renderRefundNote(order, { code: "SAVE10" }),
    "Refund for order A-1040\n\n1 x House beans 1kg     $21.60\n2 x Paper filters x100  $11.70\n\nItems                   $33.30\nShipping                 $5.99\nTax                      $2.66\nRefund                  $41.95",
  );
});

test("refund-order prints the note, or --json the amounts", () => {
  const cli = (...args) => spawnSync(process.execPath, [at("../bin/refund-order.js"), ...args], { encoding: "utf8" });
  assert.match(cli(at("../examples/order.json")).stdout, /^Refund +\$45\.95$/m);
  assert.deepEqual(JSON.parse(cli(at("../examples/order.json"), "--json").stdout), { items: 3700, fee: 0, shipping: 599, tax: 296, total: 4595 });
  assert.match(cli(at("../examples/order.json"), "--sku", "BEANS-1KG", "--opened", "BEANS-1KG").stdout, /^Restocking fee +-\$3\.60$/m);
  assert.deepEqual(JSON.parse(cli(at("../examples/order.json"), "--sku", "FILTER-100", "--code", "SAVE10", "--json").stdout), { items: 1170, fee: 0, shipping: 0, tax: 93, total: 1263 });
  assert.match(cli(at("../examples/order.json"), "--sku", "FILTER-100", "--code", "SAVE10").stdout, /^2 x Paper filters x100 +\$11\.70$/m);
  const unknown = cli(at("../examples/order.json"), "--sku", "TEA-50");
  assert.equal(unknown.status, 1);
  assert.match(unknown.stderr, /TEA-50/);
  assert.equal(cli().status, 1);
});
