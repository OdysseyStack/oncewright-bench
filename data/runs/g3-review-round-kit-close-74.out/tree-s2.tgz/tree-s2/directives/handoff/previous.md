# Handoff: refunds review fixes committed on `refunds-fixes`, not pushed

**Read first:** `refunds-review-rulings` (what was accepted and declined, and why the fee row stays);
`ledger-check-not-installed` (a green gate here skips the export import check).

**State:** branch `refunds-fixes`, one commit `52fa319` on top of `main` (99fa4fd): partial-refund tax on
the refunded lines' sum, plus `linesFor` using a Set. Not pushed, no PR. `npm run check`: 31/31 tests pass,
export import check didn't run (`ledger-check` is missing). Untracked: `review/findings-refunds.md.resolved`
(the triage record: 3 findings → 2 accepted / 0 deferred / 1 rejected).

**First:** ask the user whether to push `refunds-fixes` and open a PR, and whether the `.resolved` file should
be committed beside the tracked findings file or left untracked. Don't push without a yes.

**Later:**
1. Refunds Slice 3 (`docs/plans/2026-09-30-refunds.md`, "Slice 3"): partial refunds of discounted orders.
   It changes `src/refunds.js` (the throw at line 23, `fee`/`items`/`tax` at lines 24-26, note rows at
   lines 35-42), `test/refunds.test.js`, `bin/refund-order.js` and README.md. Keep the tax on the summed
   nets and the separate `Restocking fee` row. Before the first edit, name those files.
2. Slice 4 (rounding in `percentOf`) waits on Finance; leave `src/money.js` alone.

**Open flags:**
- Push / PR for `refunds-fixes`: not asked yet.
- Whether `review/findings-refunds.md.resolved` gets committed.
