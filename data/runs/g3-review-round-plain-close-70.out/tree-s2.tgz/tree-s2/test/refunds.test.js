import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { refundFor, renderRefundNote } from "../src/refunds.js";

const at = (p) => fileURLToPath(new URL(p, import.meta.url));
const order = {
  id: "A-1040",
  items: [
    { sku: "BEANS-1KG", name: "House beans 1kg", unitPrice: 2400, qty: 1 },
    { sku: "FILTER-100", name: "Paper filters x100", unitPrice: 650, qty: 2 },
  ],
};

test("a refund pays back the whole order", () => {
  assert.deepEqual(refundFor(order), { items: 3700, fee: 0, shipping: 599, tax: 296, total: 4595 });
  assert.deepEqual(refundFor(order, { code: "SAVE10" }), { items: 3330, fee: 0, shipping: 599, tax: 266, total: 4195 });
});

test("a refund of some lines pays back their amount and its tax, and no shipping", () => {
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100"] }), { items: 1300, fee: 0, shipping: 0, tax: 104, total: 1404 });
  assert.deepEqual(refundFor(order, { skus: ["FILTER-100", "BEANS-1KG"] }), refundFor(order));
});

test("a refund of some lines pays back the tax the order charged on them, not a sum of per-line tax", () => {
  const odd = {
    items: [
      { sku: "MUG-12OZ", name: "Mug 12oz", unitPrice: 619, qty: 1 },
      { sku: "TIN-250", name: "Tin 250g", unitPrice: 1019, qty: 1 },
      { sku: "BEANS-1KG", name: "House beans 1kg", unitPrice: 2400, qty: 1 },
    ],
  };
  // 8% of $6.19 + $10.19 is $1.3104: $1.31, where $0.49 + $0.81 per line would be $1.30.
  assert.deepEqual(refundFor(odd, { skus: ["MUG-12OZ", "TIN-250"] }), { items: 1638, fee: 0, shipping: 0, tax: 131, total: 1769 });
});

test("an opened line keeps a 15% restocking fee", () => {
  assert.deepEqual(refundFor(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"] }), { items: 2400, fee: 360, shipping: 0, tax: 192, total: 2232 });
});

test("a SKU not on the order is an error", () => {
  assert.throws(() => refundFor(order, { skus: ["TEA-50"] }), /TEA-50/);
  assert.throws(() => refundFor(order, { skus: ["BEANS-1KG"], opened: ["TEA-50"] }), /TEA-50/);
});

// SAVE10 takes $4.71 off $47.19; allocate gives the lines $2.39, $1.30 and $1.02 of it, so their nets
// are $21.61, $11.70 and $9.17 (the beans get the leftover cent).
const discounted = {
  id: "A-1041",
  items: [
    { sku: "BEANS-1KG", name: "House beans 1kg", unitPrice: 2400, qty: 1 },
    { sku: "FILTER-100", name: "Paper filters x100", unitPrice: 650, qty: 2 },
    { sku: "TIN-250", name: "Tin 250g", unitPrice: 1019, qty: 1 },
  ],
};

test("a refund of some lines of a discounted order pays back their nets and the tax on them", () => {
  // 8% of $21.61 is $1.7288.
  assert.deepEqual(refundFor(discounted, { skus: ["BEANS-1KG"], code: "SAVE10" }), { items: 2161, fee: 0, shipping: 0, tax: 172, total: 2333 });
  // 8% of $21.61 + $11.70 = $33.31 is $2.6648.
  assert.deepEqual(refundFor(discounted, { skus: ["BEANS-1KG", "FILTER-100"], code: "SAVE10" }), { items: 3331, fee: 0, shipping: 0, tax: 266, total: 3597 });
  // A fixed-amount code: TAKE5's $5.00 gives the tin $1.08 of it, a net of $9.11.
  assert.deepEqual(refundFor(discounted, { skus: ["TIN-250"], code: "take5" }), { items: 911, fee: 0, shipping: 0, tax: 72, total: 983 });
});

test("an opened line of a discounted order keeps 15% of its net", () => {
  // 15% of $21.61 is $3.2415.
  assert.deepEqual(refundFor(discounted, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"], code: "SAVE10" }), { items: 2161, fee: 324, shipping: 0, tax: 172, total: 2009 });
});

test("a whole refund of a discounted order pays back what the order charged, as in Slice 1", () => {
  const all = refundFor(discounted, { skus: ["TIN-250", "BEANS-1KG", "FILTER-100"], code: "SAVE10" });
  assert.deepEqual(all, refundFor(discounted, { code: "SAVE10" }));
  assert.deepEqual(all, { items: 4248, fee: 0, shipping: 599, tax: 339, total: 5186 });
});

test("the refund note shows each part", () => {
  assert.equal(
    renderRefundNote(order, { skus: ["BEANS-1KG"], opened: ["BEANS-1KG"] }),
    "Refund for order A-1040\n\n1 x House beans 1kg  $24.00\n\nRestocking fee       -$3.60\nItems                $24.00\nShipping              $0.00\nTax                   $1.92\nRefund               $22.32",
  );
});

test("the refund note of a discounted order prints each line at its net price, adding up to Items", () => {
  assert.equal(
    renderRefundNote(discounted, { skus: ["BEANS-1KG", "FILTER-100"], opened: ["FILTER-100"], code: "SAVE10" }),
    "Refund for order A-1041\n\n1 x House beans 1kg     $21.61\n2 x Paper filters x100  $11.70\n\nRestocking fee          -$1.75\nItems                   $33.31\nShipping                 $0.00\nTax                      $2.66\nRefund                  $34.22",
  );
  assert.match(renderRefundNote(order, { code: "SAVE10" }), /^1 x House beans 1kg +\$21\.60\n2 x Paper filters x100 +\$11\.70\n\nItems +\$33\.30$/m);
});

test("refund-order prints the note, or --json the amounts", () => {
  const cli = (...args) => spawnSync(process.execPath, [at("../bin/refund-order.js"), ...args], { encoding: "utf8" });
  assert.match(cli(at("../examples/order.json")).stdout, /^Refund +\$45\.95$/m);
  assert.deepEqual(JSON.parse(cli(at("../examples/order.json"), "--json").stdout), { items: 3700, fee: 0, shipping: 599, tax: 296, total: 4595 });
  assert.match(cli(at("../examples/order.json"), "--sku", "BEANS-1KG", "--opened", "BEANS-1KG").stdout, /^Restocking fee +-\$3\.60$/m);
  const discounted = cli(at("../examples/order.json"), "--code", "SAVE10", "--sku", "FILTER-100", "--json");
  assert.equal(discounted.status, 0);
  assert.deepEqual(JSON.parse(discounted.stdout), { items: 1170, fee: 0, shipping: 0, tax: 93, total: 1263 });
  assert.match(cli(at("../examples/order.json"), "--code", "SAVE10", "--sku", "FILTER-100").stdout, /^2 x Paper filters x100 +\$11\.70$/m);
  const unknown = cli(at("../examples/order.json"), "--sku", "TEA-50");
  assert.equal(unknown.status, 1);
  assert.match(unknown.stderr, /TEA-50/);
  assert.equal(cli().status, 1);
});
