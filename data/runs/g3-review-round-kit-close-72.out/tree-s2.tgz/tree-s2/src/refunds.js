// Refunds: a whole order (the refund plan's Slice 1), some of its lines (Slice 2), and some lines
// of a discounted order (Slice 3).
import { config } from "./config.js";
import { formatMoney, percentOf, sumCents } from "./money.js";
import { computeTotals } from "./totals.js";

// The order's lines a refund covers, those whose SKUs are listed or all of them, each as
// { item, net }: net is the line's amount less its share of any discount, from computeTotals.
const linesFor = (order, totals, skus) => {
  const lines = order.items.map((item, i) => ({ item, net: totals.lines[i].net }));
  if (skus === undefined) return lines;
  const listed = new Set(skus);
  return lines.filter(({ item }) => listed.has(item.sku));
};

// The refund's amounts and the lines they cover.
function refund(order, options) {
  const t = computeTotals(order, options);
  const { skus, opened = [] } = options;
  const unknown = [...(skus ?? []), ...opened].find((sku) => !order.items.some((item) => item.sku === sku));
  if (unknown !== undefined) throw new Error(`SKU not on the order: ${unknown}`);
  const lines = linesFor(order, t, skus);
  const whole = lines.length === order.items.length;
  const fee = sumCents(lines.filter(({ item }) => opened.includes(item.sku)).map(({ net }) => percentOf(net, config.restockingFee)));
  const items = sumCents(lines.map(({ net }) => net));
  const tax = percentOf(items, config.taxRate);
  const shipping = whole ? t.shipping : 0;
  return { lines, amounts: { items, fee, shipping, tax, total: items - fee + shipping + tax } };
}

// What a refund pays back, in cents: { items, fee, shipping, tax, total }. options: the options the
// order was priced with (pickup, code), plus skus, the lines to refund (all of them when absent),
// and opened, the refunded lines that keep a restocking fee. Each refunded line pays back its net
// (its amount less its share of any discount); the tax is on the nets' sum, and the restocking fee
// is a share of an opened line's net.
export function refundFor(order, options = {}) {
  return refund(order, options).amounts;
}

// The note the customer gets with a refund: the refunded lines at their net prices, then the totals.
export function renderRefundNote(order, options = {}) {
  const { lines, amounts: r } = refund(order, options);
  const rows = [
    ...lines.map(({ item, net }) => [`${item.qty} x ${item.name}`, net]),
    null,
    ...(r.fee ? [["Restocking fee", -r.fee]] : []),
    ["Items", r.items],
    ["Shipping", r.shipping],
    ["Tax", r.tax],
    ["Refund", r.total],
  ].map((row) => row && [row[0], formatMoney(row[1])]);
  const width = Math.max(...rows.filter(Boolean).map(([label, amount]) => label.length + amount.length)) + 2;
  return [
    `Refund for order ${order.id ?? "(no id)"}`,
    "",
    ...rows.map((row) => (row ? row[0] + row[1].padStart(width - row[0].length) : "")),
  ].join("\n");
}
